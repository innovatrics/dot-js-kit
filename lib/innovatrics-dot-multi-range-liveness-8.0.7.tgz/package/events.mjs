const a = {};
a.CONTINUE_DETECTION = "continue-detection", a.SWITCH_CAMERA = "switch-camera", a.TOGGLE_MIRROR = "toggle-mirror";
const l = a, u = {};
u.FIRST_FRAME = "first-frame", u.FIRST_VALID_FRAME = "first-valid-frame";
const R = u, s = {};
s.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const _ = s, E = (c, o) => {
  const e = {};
  e.detail = o, document.dispatchEvent(new CustomEvent(c, e));
}, T = (c, o) => {
  const e = {};
  e.instruction = o, E(c, e);
};
function p(c) {
  const o = {};
  o.instruction = c;
  const e = o;
  E(_.REQUEST_CAPTURE, e);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const C = n, r = { ...C };
r.DONE = "done";
const N = r, i = {};
i.EYE_NOT_PRESENT = "eye_not_present";
const A = i, t = {};
t.DETECTION_CHANGED = "multi-range-auto-capture:detection-changed", t.CAMERA_PROPS_CHANGED = "multi-range-auto-capture:camera-props-changed", t.CONTROL = "multi-range-auto-capture:control", t.PHASE_CHANGED = "multi-range-auto-capture:phase-changed", t.INSTRUCTION_CHANGED = "multi-range-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "multi-range-auto-capture:instruction-escalated", t.VIDEO_ELEMENT_SIZE = "multi-range-auto-capture:video-element-size", t.CHALLENGE_VALUE_CHANGED = "multi-range-auto-capture:challenge-value-changed", t.STATE_CHANGED = "multi-range-auto-capture:state-changed";
const m = t;
export {
  C as AppStateValues,
  _ as ComponentCustomEvent,
  l as ControlEventInstruction,
  A as EyeInstructionCodeValues,
  N as LivenessStateValues,
  m as MultiRangeCustomEvent,
  R as RequestCaptureInstruction,
  p as dispatchCaptureEvent,
  T as dispatchControlEvent
};
