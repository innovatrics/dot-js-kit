# MagnifEye Liveness Component

## Overview
Innovatrics MagnifEye Liveness Component is a web component that renders the video stream from an available phone or web camera to automatically capture a detailed image of a user’s face and their eye with the required quality. The component lays the foundation for a semi-passive liveness capture capability.

The component output is multiple face and eye images in the JPEG format and/or a proprietary file format for safe transfer to [Digital Identity Service](https://developers.innovatrics.com/digital-onboarding/technical/api-reference/) on server for further processing.

<p align="center">
    <img alt="MagnifEye Liveness" src="https://www.innovatrics.com/wp-content/uploads/2024/03/MagnifEye_liveness-preview-400px.gif" width="200" height="400">
</p>

The MagnifEye Liveness Component can be used in combination with other components to develop remote identity verification or digital onboarding solutions, as demonstrated in this [demo application](https://idv.innovatrics.com/).

You can also check out the [integration samples](https://github.com/innovatrics/dot-web-samples) in various technologies (React, Vue, Angular, jQuery).

## Pre-requisites

1. **UI Component**

    **IMPORTANT**: For this component to work as intended, we highly recommend you also have the [Auto Capture UI Component](https://www.npmjs.com/package/@innovatrics/dot-auto-capture-ui) installed in your project. You can learn more about why this is important on our [developers portal](https://developers.innovatrics.com/digital-onboarding/technical/remote/dot-web-magnifeye-liveness/latest/documentation/).


2. **Camera requirements**

    To get appropriate results using this component, the camera resolution on your device needs to be at least 720x720 pixels.

3. **Supported browsers**

    The MagnifEye Liveness Component was tested with Chrome, Firefox, Edge, Safari, SafariVC, WebView and WKWebView. More information can be found [here](https://developers.innovatrics.com/digital-onboarding/technical/remote/dot-web-magnifeye-liveness/latest/documentation/#_supported_browsers).

## Installation

Installation of the package is available via NPM, PNPM or Yarn:

Using NPM:

```bash
$ npm install @innovatrics/dot-magnifeye-liveness
```

Using PNPM:

```bash
$ pnpm add @innovatrics/dot-magnifeye-liveness
```

Using Yarn:

```bash
$ yarn add @innovatrics/dot-magnifeye-liveness
```

## Usage
The MagnifEye Liveness Component is a [web component](https://developer.mozilla.org/en-US/docs/Web/Web_Components/Using_custom_elements) which uses custom HTML tag. Properties need to be passed into the component after the tag was rendered.


Head to our [developers portal](https://developers.innovatrics.com/digital-onboarding/technical/remote/dot-web-magnifeye-liveness/latest/documentation/#_usage) to learn more about:

- Initial setup
- Requesting device motion permissions for iOS
- Usage with TypeScript
- Hosting SAM wasm
- Troubleshooting
- Properties
- Callback parameters
- Error handling
- Examples of using the Face Auto Capture Component and the [Auto Capture UI Component](https://www.npmjs.com/package/@innovatrics/dot-auto-capture-ui) together

## Changelog
See changelog [here](https://developers.innovatrics.com/digital-onboarding/technical/remote/dot-web-magnifeye-liveness/latest/documentation/#_changelog).

## License
The MagnifEye Liveness Component is available under Innovatrics proprietary license.

The component can be used in a freemium mode without a license agreement. However, please note that the free version includes a watermark overlay in the component.

To obtain a license agreement and use the component without the overlay, please contact us at support@innovatrics.com.
