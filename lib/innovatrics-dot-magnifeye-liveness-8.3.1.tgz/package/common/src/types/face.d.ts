import type { BaseConfiguration } from './configuration';
import type { MaxInterval, MinInterval, MinOrMaxInterval, Resolution } from '../../../ui-common/src/types/index.js';
import type { DetectedFace } from '../../../ui-common/src/types/modality/detection/face.js';
export * from '../../../ui-common/src/types/common.js';
export * from '../../../ui-common/src/types/face.js';
export * from '../../../ui-common/src/error/index.js';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
}
export type FaceComponentData = {
    detection: DetectedFace;
    imageResolution: Resolution;
};
export type EyeThresholds = {
    confidence: MinInterval;
};
export type MouthThresholds = {
    confidence: MinInterval;
    status: {
        max: number;
        min?: number;
    } | {
        max?: number;
        min: number;
    };
};
export type FaceThresholds = {
    brightness?: MinOrMaxInterval;
    confidence?: MinInterval;
    devicePitchAngle?: MaxInterval;
    edgeDistanceToImageShorterSideRatio?: MinInterval;
    leftEye?: EyeThresholds;
    mouth?: MouthThresholds;
    rightEye?: EyeThresholds;
    sharpness?: MinInterval;
    size?: MinOrMaxInterval;
};
export type PublicFaceThresholds = Omit<FaceThresholds, 'leftEye' | 'rightEye' | 'mouth'>;
export type FaceConfiguration<T = PublicFaceThresholds> = BaseConfiguration<DetectedFace, T>;
