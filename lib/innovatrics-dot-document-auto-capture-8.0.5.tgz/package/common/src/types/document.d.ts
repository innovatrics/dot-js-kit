import type { BaseConfiguration } from './configuration';
import type { CallbackImage, CustomElement, MaxInterval, MinInterval, MinOrMaxInterval, Resolution } from '../../../ui-common/src/types';
import type { DetectedDocument } from '../../../ui-common/src/types/modality/detection/document';
export * from '../../../ui-common/src/types/common';
export * from '../../../ui-common/src/types/document';
export * from '../../../ui-common/src/error';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-document-auto-capture': CustomElement<{
                configuration: DocumentConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-document-auto-capture': CustomElement<{
                configuration: DocumentConfiguration;
            }>;
        }
    }
}
export type HTMLDocumentCaptureElement = HTMLElement & {
    configuration: DocumentConfiguration;
};
export type DocumentComponentData = {
    detection: DetectedDocument;
    imageResolution: Resolution;
};
export type DocumentThresholds = {
    brightness?: MinOrMaxInterval;
    confidence?: MinInterval;
    edgeDistanceToImageShorterSideRatio?: MinInterval;
    hotspotsScore?: MaxInterval;
    sharpness?: MinInterval;
    size?: MinInterval;
};
export type DocumentConfiguration = BaseConfiguration<DetectedDocument, DocumentThresholds>;
export type DocumentOnCompleteCallbackImage = CallbackImage<DetectedDocument>;
export type DocumentOnCompleteCallback = DocumentConfiguration['onComplete'];
