const s = {};
s.CONTINUE_DETECTION = "continue-detection", s.SWITCH_CAMERA = "switch-camera", s.TOGGLE_MIRROR = "toggle-mirror";
const I = s, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const d = T, a = {};
a.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const C = a, r = (e, c) => {
  const _ = {};
  _.detail = c, document.dispatchEvent(new CustomEvent(e, _));
}, A = (e, c) => {
  const _ = {};
  _.instruction = c, r(e, _);
};
function h(e) {
  const c = {};
  c.instruction = e;
  const _ = c;
  r(C.REQUEST_CAPTURE, _);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const R = n, i = { ...R };
i.DONE = "done";
const H = i, N = {};
N.EYE_NOT_PRESENT = "eye_not_present";
const O = N, t = {};
t.CANDIDATE_SELECTION = "candidate_selection", t.FACE_TOO_CLOSE = "face_too_close", t.FACE_TOO_FAR = "face_too_far", t.FACE_CENTERING = "face_centering", t.FACE_NOT_PRESENT = "face_not_present", t.SHARPNESS_TOO_LOW = "sharpness_too_low", t.BRIGHTNESS_TOO_LOW = "brightness_too_low", t.BRIGHTNESS_TOO_HIGH = "brightness_too_high", t.DEVICE_PITCHED = "device_pitched", t.LEFT_EYE_NOT_PRESENT = "left_" + O.EYE_NOT_PRESENT, t.RIGHT_EYE_NOT_PRESENT = "right_" + O.EYE_NOT_PRESENT, t.MOUTH_NOT_PRESENT = "mouth_not_present", t.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", t.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const E = t, o = {};
o.isPresent = E.FACE_NOT_PRESENT, o.isNotPitched = E.DEVICE_PITCHED, o.isNotSmall = E.FACE_TOO_FAR, o.isNotLarge = E.FACE_TOO_CLOSE, o.isNotOutOfBounds = E.FACE_CENTERING, o.isNotDim = E.BRIGHTNESS_TOO_LOW, o.isNotBright = E.BRIGHTNESS_TOO_HIGH, o.isSharp = E.SHARPNESS_TOO_LOW, o.isLeftEyePresent = E.LEFT_EYE_NOT_PRESENT, o.isRightEyePresent = E.RIGHT_EYE_NOT_PRESENT, o.isMouthPresent = E.MOUTH_NOT_PRESENT, o.isMouthScoreNotTooHigh = E.MOUTH_SCORE_TOO_HIGH, o.isMouthScoreNotTooLow = E.MOUTH_SCORE_TOO_LOW;
const p = o;
var u = ((e) => (e.CAMERA_PROPS_CHANGED = "face-auto-capture:camera-props-changed", e.CONTROL = "face-auto-capture:control", e.DETECTION_CHANGED = "face-auto-capture:detection-changed", e.FACE_DETECTION = "face-auto-capture:face-detection", e.INSTRUCTION_CHANGED = "face-auto-capture:instruction-changed", e.STATE_CHANGED = "face-auto-capture:state-changed", e.VIDEO_ELEMENT_SIZE = "face-auto-capture:video-element-size", e))(u || {});
export {
  R as AppStateValues,
  C as ComponentCustomEvent,
  I as ControlEventInstruction,
  O as EyeInstructionCodeValues,
  p as FaceCheckToInstructionCodeMap,
  u as FaceCustomEvent,
  E as FaceInstructionCodeValues,
  H as LivenessStateValues,
  d as RequestCaptureInstruction,
  h as dispatchCaptureEvent,
  A as dispatchControlEvent
};
