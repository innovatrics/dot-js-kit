export * from '../../../../ui-common/src/error/auto-capture-error.js';
export * from '../../../../ui-common/src/types/common.js';
export * from '../../../../ui-common/src/types/document.js';
export type { DetectedDocument, DetectedDocumentCorners, DocumentImageParameters, } from '../../../../ui-common/src/types/modality/detection/document.js';
export type { CameraFacingMode, CameraFacingModeValues, CaptureMode, CaptureModeValues } from './common';
export * from './document';
