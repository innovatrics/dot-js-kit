import type { BaseConfiguration, CaptureConfiguration } from './configuration';
import type { CallbackImage, CustomElement, MaxInterval, MinInterval, MinOrMaxInterval, Resolution } from '../../../../ui-common/src/types/common.js';
import type { DetectedDocument } from '../../../../ui-common/src/types/modality/detection/document.js';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-document-auto-capture': CustomElement<{
                configuration: DocumentConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-document-auto-capture': CustomElement<{
                configuration: DocumentConfiguration;
            }>;
        }
    }
}
export type HTMLDocumentCaptureElement = HTMLElement & {
    configuration: DocumentConfiguration;
};
export type DocumentThresholds = {
    brightness?: MinOrMaxInterval;
    confidence?: MinInterval;
    edgeDistanceToImageShorterSideRatio?: MinInterval;
    hotspotsScore?: MaxInterval;
    sharpness?: MinInterval;
    size?: MinInterval;
};
export type DocumentComponentData = {
    detection: DetectedDocument;
    imageResolution: Resolution;
};
export type DocumentConfiguration = BaseConfiguration<CallbackImage<DetectedDocument>> & CaptureConfiguration<DocumentThresholds>;
export type DocumentOnCompleteCallbackImage = CallbackImage<DetectedDocument>;
export type DocumentOnCompleteCallback = DocumentConfiguration['onComplete'];
