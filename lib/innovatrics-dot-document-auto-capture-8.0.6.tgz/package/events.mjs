const _ = {};
_.CONTINUE_DETECTION = "continue-detection", _.SWITCH_CAMERA = "switch-camera", _.TOGGLE_MIRROR = "toggle-mirror";
const R = _, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const S = T, u = {};
u.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const N = u, a = (t, E) => {
  const e = {};
  e.detail = E, document.dispatchEvent(new CustomEvent(t, e));
}, I = (t, E) => {
  const e = {};
  e.instruction = E, a(t, e);
};
function m(t) {
  const E = {};
  E.instruction = t;
  const e = E;
  a(N.REQUEST_CAPTURE, e);
}
const s = {};
s.LOADING = "loading", s.ERROR = "error", s.WAITING = "waiting", s.RUNNING = "running", s.COMPLETE = "complete", s.BLURRED = "blurred";
const i = s, r = { ...i };
r.DONE = "done";
const p = r, O = {};
O.EYE_NOT_PRESENT = "eye_not_present";
const A = O, o = {};
o.CANDIDATE_SELECTION = "candidate_selection", o.DOCUMENT_CENTERING = "document_centering", o.DOCUMENT_NOT_PRESENT = "document_not_present", o.DOCUMENT_TOO_FAR = "document_too_far", o.SHARPNESS_TOO_LOW = "sharpness_too_low", o.BRIGHTNESS_TOO_LOW = "brightness_too_low", o.BRIGHTNESS_TOO_HIGH = "brightness_too_high", o.HOTSPOTS_PRESENT = "hotspots_present";
const c = o, n = {};
n.isPresent = c.DOCUMENT_NOT_PRESENT, n.isNotSmall = c.DOCUMENT_TOO_FAR, n.isNotOutOfBounds = c.DOCUMENT_CENTERING, n.isSharp = c.SHARPNESS_TOO_LOW, n.isNotDim = c.BRIGHTNESS_TOO_LOW, n.isNotBright = c.BRIGHTNESS_TOO_HIGH, n.noHotspots = c.HOTSPOTS_PRESENT;
const D = n;
var d = ((t) => (t.CAMERA_PROPS_CHANGED = "document-auto-capture:camera-props-changed", t.CONTROL = "document-auto-capture:control", t.DETECTION_CHANGED = "document-auto-capture:detection-changed", t.INSTRUCTION_CHANGED = "document-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "document-auto-capture:instruction-escalated", t.STATE_CHANGED = "document-auto-capture:state-changed", t.VIDEO_ELEMENT_SIZE = "document-auto-capture:video-element-size", t))(d || {});
export {
  i as AppStateValues,
  N as ComponentCustomEvent,
  R as ControlEventInstruction,
  D as DocumentCheckToInstructionCodeMap,
  d as DocumentCustomEvent,
  c as DocumentInstructionCodeValues,
  A as EyeInstructionCodeValues,
  p as LivenessStateValues,
  S as RequestCaptureInstruction,
  m as dispatchCaptureEvent,
  I as dispatchControlEvent
};
