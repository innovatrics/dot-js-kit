const a = {};
a.CONTINUE_DETECTION = "continue-detection", a.SWITCH_CAMERA = "switch-camera", a.TOGGLE_MIRROR = "toggle-mirror";
const l = a, c = {};
c.FIRST_FRAME = "first-frame", c.FIRST_VALID_FRAME = "first-valid-frame";
const p = c, T = {};
T.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const N = T, i = (t, s) => {
  const _ = {};
  _.detail = s, document.dispatchEvent(new CustomEvent(t, _));
}, R = (t, s) => {
  const _ = {};
  _.instruction = s, i(t, _);
};
function A(t) {
  const s = {};
  s.instruction = t;
  const _ = s;
  i(N.REQUEST_CAPTURE, _);
}
const E = {};
E.LOADING = "loading", E.ERROR = "error", E.WAITING = "waiting", E.RUNNING = "running", E.COMPLETE = "complete", E.BLURRED = "blurred";
const C = E, r = { ...C };
r.DONE = "done";
const d = r, O = {};
O.EYE_NOT_PRESENT = "eye_not_present";
const S = O, e = {};
e.CANDIDATE_SELECTION = "candidate_selection", e.PALM_CENTERING = "palm_centering", e.PALM_NOT_PRESENT = "palm_not_present", e.PALM_TOO_FAR = "palm_too_far", e.PALM_TOO_CLOSE = "palm_too_close", e.SHARPNESS_TOO_LOW = "sharpness_too_low", e.BRIGHTNESS_TOO_LOW = "brightness_too_low", e.BRIGHTNESS_TOO_HIGH = "brightness_too_high", e.DEVICE_PITCHED = "device_pitched", e.TEMPLATE_EXTRACTION_QUALITY_TOO_LOW = "template_extraction_quality_too_low";
const n = e, o = {};
o.isPresent = n.PALM_NOT_PRESENT, o.isNotPitched = n.DEVICE_PITCHED, o.isNotSmall = n.PALM_TOO_FAR, o.isNotOutOfBounds = n.PALM_CENTERING, o.isNotDim = n.BRIGHTNESS_TOO_LOW, o.isNotBright = n.BRIGHTNESS_TOO_HIGH, o.isSharp = n.SHARPNESS_TOO_LOW, o.isNotLarge = n.PALM_TOO_CLOSE, o.isTemplateExtractionQualityHighEnough = n.TEMPLATE_EXTRACTION_QUALITY_TOO_LOW;
const m = o;
var u = ((t) => (t.CAMERA_PROPS_CHANGED = "palm-capture:camera-props-changed", t.CONTROL = "palm-capture:control", t.DETECTION_CHANGED = "palm-capture:detection-changed", t.INSTRUCTION_CHANGED = "palm-capture:instruction-changed", t.STATE_CHANGED = "palm-capture:state-changed", t.VIDEO_ELEMENT_SIZE = "palm-capture:video-element-size", t))(u || {});
export {
  C as AppStateValues,
  N as ComponentCustomEvent,
  l as ControlEventInstruction,
  S as EyeInstructionCodeValues,
  d as LivenessStateValues,
  m as PalmCheckToInstructionCodeMap,
  u as PalmCustomEvent,
  n as PalmInstructionCodeValues,
  p as RequestCaptureInstruction,
  A as dispatchCaptureEvent,
  R as dispatchControlEvent
};
