import type { BaseConfiguration } from './configuration';
import type { CallbackImage, CustomElement } from '../../../../ui-common/src/types/common';
import type { DetectedFace } from '../../../../ui-common/src/types/modality/detection/face';
import type { MultiRangeLivenessChallengeItemValues } from '../../../../ui-common/src/types/multi-range';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-multi-range-liveness': CustomElement<{
                configuration: Configuration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-multi-range-liveness': CustomElement<{
                configuration: Configuration;
            }>;
        }
    }
}
export type HTMLMultiRangeLivenessElement = HTMLElement & {
    configuration: Configuration;
};
export type Configuration = BaseConfiguration<OnCompleteCallbackImage> & {
    challengeSequence: Array<MultiRangeLivenessChallengeItemValues>;
};
export type OnCompleteCallbackImage = {
    imageWithMetadata: CallbackImage<DetectedFace>;
};
export type OnCompleteCallback = (resultData: OnCompleteCallbackImage, content: Uint8Array) => void;
