# Multi-Range Liveness Component 

## Overview

Innovatrics Multi-Range Liveness Component is a web component that renders the video stream from an available phone or web camera to automatically capture multiple images of a user’s face in random distances with the required quality. The component lays the foundation for an active liveness capture capability.

The component output is multiple face images in the JPEG format and/or a proprietary file format for safe transfer to [Digital Identity Service](https://developers.innovatrics.com/digital-onboarding/technical/api-reference/) on server for further processing.

<p align="center">
  <img alt="Multi-Range Liveness" src="https://www.innovatrics.com/wp-content/uploads/2025/12/multirange_resized.gif" width="200" height="400">
</p>

The Multi-Range Liveness Component can be used in combination with other components to develop remote identity verification or digital onboarding solutions, as demonstrated in this [demo application](https://idv.innovatrics.com/).

You can also check out the [integration samples](https://github.com/innovatrics/dot-web-samples) in various technologies (React, Vue, Angular, jQuery).

## Pre-requisites

1. **UI Component**

   **IMPORTANT**: For this component to work as intended, we highly recommend you also have the [Auto Capture UI Component](https://www.npmjs.com/package/@innovatrics/dot-auto-capture-ui) installed in your project. You can learn more about why this is important on our [developers portal](https://developers.innovatrics.com/digital-onboarding/technical/remote/dot-web-multi-range-liveness/latest/documentation/).

2. **Camera requirements**

   To get appropriate results using this component, the camera resolution on your device needs to be at least 720x720 pixels.

3. **Supported browsers**

   The Multi-Range Liveness Component was tested with Chrome, Firefox, Edge, Safari, SafariVC, WebView and WKWebView. More information can be found [here](https://developers.innovatrics.com/digital-onboarding/technical/remote/dot-web-multi-range-liveness/latest/documentation/#_supported_browsers).

## Installation

Installation of the package is available via NPM, PNPM or Yarn:

Using NPM:

```bash
$ npm install @innovatrics/dot-multi-range-liveness
```

Using PNPM:

```bash
$ pnpm add @innovatrics/dot-multi-range-liveness
```

Using Yarn:

```bash
$ yarn add @innovatrics/dot-multi-range-liveness
```

## Usage

The Multi-Range Liveness Component is a [web component](https://developer.mozilla.org/en-US/docs/Web/Web_Components/Using_custom_elements) which uses custom HTML tag. Properties need to be passed into the component after the tag was rendered.

Head to our [developers portal](https://developers.innovatrics.com/digital-onboarding/technical/remote/dot-web-multi-range-liveness/latest/documentation/#_usage) to learn more about:

- Initial setup
- Usage with TypeScript
- Hosting SAM wasm
- Troubleshooting
- Properties
- Callback parameters
- Multi capture capabilities
- Error handling
- Custom events - communication between the Multi-Range Liveness Component and the [Auto Capture UI Component](https://www.npmjs.com/package/@innovatrics/dot-auto-capture-ui)
- Examples of using the Multi-Range Liveness Component and the [Auto Capture UI Component](https://www.npmjs.com/package/@innovatrics/dot-auto-capture-ui) together

## Changelog

See changelog [here](https://developers.innovatrics.com/digital-onboarding/technical/remote/dot-web-multi-range-liveness/latest/documentation/#_changelog).

## License

The Multi-Range Liveness Component is available under Innovatrics proprietary license.

The component can be used in a freemium mode without a license agreement. However, please note that the free version includes a watermark overlay in the component.

To obtain a license agreement and use the component without the overlay, please contact us at support@innovatrics.com.
