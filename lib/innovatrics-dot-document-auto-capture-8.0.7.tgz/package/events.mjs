const _ = {};
_.CONTINUE_DETECTION = "continue-detection", _.SWITCH_CAMERA = "switch-camera", _.TOGGLE_MIRROR = "toggle-mirror";
const R = _, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const S = T, u = {};
u.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const N = u, a = (t, E) => {
  const n = {};
  n.detail = E, document.dispatchEvent(new CustomEvent(t, n));
}, I = (t, E) => {
  const n = {};
  n.instruction = E, a(t, n);
};
function m(t) {
  const E = {};
  E.instruction = t;
  const n = E;
  a(N.REQUEST_CAPTURE, n);
}
const s = {};
s.LOADING = "loading", s.ERROR = "error", s.WAITING = "waiting", s.RUNNING = "running", s.COMPLETE = "complete", s.BLURRED = "blurred";
const i = s, r = { ...i };
r.DONE = "done";
const p = r, O = {};
O.EYE_NOT_PRESENT = "eye_not_present";
const A = O, e = {};
e.CANDIDATE_SELECTION = "candidate_selection", e.DOCUMENT_CENTERING = "document_centering", e.DOCUMENT_NOT_PRESENT = "document_not_present", e.DOCUMENT_TOO_FAR = "document_too_far", e.SHARPNESS_TOO_LOW = "sharpness_too_low", e.BRIGHTNESS_TOO_LOW = "brightness_too_low", e.BRIGHTNESS_TOO_HIGH = "brightness_too_high", e.HOTSPOTS_PRESENT = "hotspots_present";
const c = e, o = {};
o.isPresent = c.DOCUMENT_NOT_PRESENT, o.isNotSmall = c.DOCUMENT_TOO_FAR, o.isNotOutOfBounds = c.DOCUMENT_CENTERING, o.isSharp = c.SHARPNESS_TOO_LOW, o.isNotDim = c.BRIGHTNESS_TOO_LOW, o.isNotBright = c.BRIGHTNESS_TOO_HIGH, o.noHotspots = c.HOTSPOTS_PRESENT;
const D = o;
var C = ((t) => (t.CAMERA_PROPS_CHANGED = "document-auto-capture:camera-props-changed", t.CONTROL = "document-auto-capture:control", t.DETECTION_CHANGED = "document-auto-capture:detection-changed", t.INSTRUCTION_CHANGED = "document-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "document-auto-capture:instruction-escalated", t.STATE_CHANGED = "document-auto-capture:state-changed", t.VIDEO_ELEMENT_SIZE = "document-auto-capture:video-element-size", t))(C || {});
export {
  i as AppStateValues,
  N as ComponentCustomEvent,
  R as ControlEventInstruction,
  D as DocumentCheckToInstructionCodeMap,
  C as DocumentCustomEvent,
  c as DocumentInstructionCodeValues,
  A as EyeInstructionCodeValues,
  p as LivenessStateValues,
  S as RequestCaptureInstruction,
  m as dispatchCaptureEvent,
  I as dispatchControlEvent
};
