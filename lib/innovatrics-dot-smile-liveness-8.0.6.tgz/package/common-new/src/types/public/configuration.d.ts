import type { CameraFacingModeValues } from './common';
export type CommonConfiguration = {
    assetsDirectoryPath?: string;
    sessionToken?: string;
    styleTarget?: HTMLElement;
    transactionCountingToken?: string;
};
export type CameraConfiguration = {
    facingMode?: CameraFacingModeValues;
    isVideoCaptureEnabled?: boolean;
};
export type CallbackConfiguration<TResultImageWithMetadata = unknown> = {
    onComplete(resultData: TResultImageWithMetadata, content: Uint8Array): void;
    onError(e: Error): void;
};
export type BaseConfiguration<TResultImageWithMetadata = unknown> = CommonConfiguration & CallbackConfiguration<TResultImageWithMetadata> & {
    camera?: CameraConfiguration;
};
