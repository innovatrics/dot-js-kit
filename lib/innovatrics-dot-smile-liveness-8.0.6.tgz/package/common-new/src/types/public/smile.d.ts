import type { BaseConfiguration } from './configuration';
import type { CallbackImage, CustomElement, MinOrMaxInterval } from '../../../../ui-common/src/types/common';
import type { DetectedFace } from '../../../../ui-common/src/types/modality/detection/face';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-smile-liveness': CustomElement<{
                configuration: Configuration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-smile-liveness': CustomElement<{
                configuration: Configuration;
            }>;
        }
    }
}
type PublicThresholds = {
    size?: MinOrMaxInterval;
};
export type Configuration = BaseConfiguration<OnCompleteCallbackImages> & {
    qualityAttributeThresholds?: PublicThresholds;
};
export type HTMLSmileLivenessElement = HTMLElement & {
    configuration: Configuration;
};
export type OnCompleteCallbackImages = {
    neutralPhaseImageWithMetadata: CallbackImage<DetectedFace>;
    smilePhaseImageWithMetadata: CallbackImage<DetectedFace>;
};
export type OnCompleteCallback = (resultData: OnCompleteCallbackImages, content: Uint8Array) => void;
export {};
