type CustomEvents<K extends string> = {
    [key in K]: (event: CustomEvent) => void;
};
export type CustomElement<T, K extends string = ''> = Partial<T & HTMLElement & {
    children: unknown;
} & CustomEvents<`on${K}`> & {
    ref?: unknown;
}>;
export type DeepRequired<T> = Required<{
    [P in keyof T]: T[P] extends Record<string, unknown> | undefined ? DeepRequired<Required<T[P]>> : T[P];
}>;
export type DeepPartial<T> = T extends object ? {
    [P in keyof T]?: DeepPartial<T[P]>;
} : T;
export type RequireSome<T, K extends keyof T> = T & {
    [P in K]-?: T[P];
};
export type ObjectValues<T> = T[keyof T];
export type ImageParameters = {
    brightness: number;
    sharpness: number;
};
export type CameraSettings = MediaTrackSettings & {
    deviceName?: string;
};
export type Resolution = {
    height: number;
    width: number;
};
export type Point = {
    x: number;
    y: number;
};
export declare const AppStateValues: {
    readonly LOADING: "loading";
    readonly ERROR: "error";
    readonly WAITING: "waiting";
    readonly RUNNING: "running";
    readonly COMPLETE: "complete";
};
export declare const LivenessStateValues: {
    readonly DONE: "done";
    readonly LOADING: "loading";
    readonly ERROR: "error";
    readonly WAITING: "waiting";
    readonly RUNNING: "running";
    readonly COMPLETE: "complete";
};
export type AppState = ObjectValues<typeof AppStateValues>;
export type LivenessAppState = ObjectValues<typeof LivenessStateValues>;
export type Crop = {
    height: number;
    shiftX: number;
    shiftY: number;
    width: number;
};
export type CallbackImage<TDetectedObject> = {
    data: CallbackImageMetadata<TDetectedObject>;
    image: Blob;
};
export type CallbackImageMetadata<TDetectedObject> = {
    detection: TDetectedObject;
    imageResolution: Resolution;
};
export type DetectedCorners = {
    bottomLeft: Point;
    bottomRight: Point;
    topLeft: Point;
    topRight: Point;
};
export type MinOrMaxInterval = {
    max?: number;
    min?: number;
};
export type MinInterval = {
    min?: number;
};
export type MaxInterval = {
    max?: number;
};
export declare const EyeInstructionCodeValues: {
    readonly EYE_NOT_PRESENT: "eye_not_present";
};
export {};
