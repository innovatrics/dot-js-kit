import type { ObjectValues } from './common';
export declare const MultiRangeInstructionCodeValues: {
    readonly CANDIDATE_SELECTION: "candidate_selection";
    readonly FACE_TOO_CLOSE: "face_too_close";
    readonly FACE_TOO_FAR: "face_too_far";
    readonly FACE_CENTERING: "face_centering";
    readonly FACE_NOT_PRESENT: "face_not_present";
    readonly SHARPNESS_TOO_LOW: "sharpness_too_low";
    readonly BRIGHTNESS_TOO_LOW: "brightness_too_low";
    readonly BRIGHTNESS_TOO_HIGH: "brightness_too_high";
    readonly DEVICE_PITCHED: "device_pitched";
    readonly LEFT_EYE_NOT_PRESENT: "left_eye_not_present";
    readonly RIGHT_EYE_NOT_PRESENT: "right_eye_not_present";
};
export type MultiRangeInstructionCode = ObjectValues<typeof MultiRangeInstructionCodeValues>;
export declare const MultiRangeCheckToInstructionCodeMap: {
    isPresent: "face_not_present";
    isNotPitched: "device_pitched";
    isNotSmall: "face_too_far";
    isNotLarge: "face_too_close";
    isNotOutOfBounds: "face_centering";
    isNotDim: "brightness_too_low";
    isNotBright: "brightness_too_high";
    isSharp: "sharpness_too_low";
    isLeftEyePresent: "left_eye_not_present";
    isRightEyePresent: "right_eye_not_present";
};
export type MultiRangeEscalatedInstructionCodes = typeof MultiRangeInstructionCodeValues.FACE_TOO_CLOSE | typeof MultiRangeInstructionCodeValues.FACE_TOO_FAR;
export declare const MultiRangeLivenessChallengeItem: {
    readonly ZERO: "ZERO";
    readonly ONE: "ONE";
    readonly TWO: "TWO";
    readonly THREE: "THREE";
    readonly FOUR: "FOUR";
    readonly FIVE: "FIVE";
};
export type MultiRangeLivenessChallengeItemValues = ObjectValues<typeof MultiRangeLivenessChallengeItem>;
