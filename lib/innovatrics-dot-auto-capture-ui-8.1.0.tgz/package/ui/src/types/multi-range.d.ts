import type { EscalatedInstructions, HTMLElementWithConfiguration, UiAppStateInstructions } from './common';
import type { BaseUiConfiguration, InitializedBaseUiConfiguration, InitializedUiControlsConfiguration, UiControlsConfiguration } from './configuration';
import type { CustomElement, MultiRangeEscalatedInstructionCodes, MultiRangeInstructionCode } from '../../../ui-common/src/types';
export * from './common';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-multi-range-liveness-ui': CustomElement<{
                configuration: MultiRangeUiConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-multi-range-liveness-ui': CustomElement<{
                configuration: MultiRangeUiConfiguration;
            }>;
        }
    }
}
export type MultiRangeInstructions = Record<MultiRangeInstructionCode, string>;
export type MultiRangeUiConfiguration = BaseUiConfiguration<MultiRangeInstructions, UiControlsConfiguration, UiAppStateInstructions> & EscalatedInstructions<MultiRangeEscalatedInstructionCodes>;
export type InitializedMultiRangeUiConfiguration = InitializedBaseUiConfiguration<MultiRangeInstructions, InitializedUiControlsConfiguration, UiAppStateInstructions> & EscalatedInstructions<MultiRangeEscalatedInstructionCodes>;
export type HTMLMultiRangeLivenessUiElement = HTMLElementWithConfiguration<MultiRangeUiConfiguration>;
