const _ = {};
_.CONTINUE_DETECTION = "continue-detection", _.SWITCH_CAMERA = "switch-camera", _.TOGGLE_MIRROR = "toggle-mirror";
const R = _, a = {};
a.FIRST_FRAME = "first-frame", a.FIRST_VALID_FRAME = "first-valid-frame";
const S = a, T = {};
T.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const N = T, u = (t, E) => {
  const n = {};
  n.detail = E, document.dispatchEvent(new CustomEvent(t, n));
}, I = (t, E) => {
  const n = {};
  n.instruction = E, u(t, n);
};
function m(t) {
  const E = {};
  E.instruction = t;
  const n = E;
  u(N.REQUEST_CAPTURE, n);
}
const c = {};
c.LOADING = "loading", c.ERROR = "error", c.WAITING = "waiting", c.RUNNING = "running", c.COMPLETE = "complete", c.BLURRED = "blurred";
const i = c, r = { ...i };
r.DONE = "done";
const p = r, O = {};
O.EYE_NOT_PRESENT = "eye_not_present";
const A = O, e = {};
e.CANDIDATE_SELECTION = "candidate_selection", e.DOCUMENT_CENTERING = "document_centering", e.DOCUMENT_NOT_PRESENT = "document_not_present", e.DOCUMENT_TOO_FAR = "document_too_far", e.SHARPNESS_TOO_LOW = "sharpness_too_low", e.BRIGHTNESS_TOO_LOW = "brightness_too_low", e.BRIGHTNESS_TOO_HIGH = "brightness_too_high", e.HOTSPOTS_PRESENT = "hotspots_present";
const s = e, o = {};
o.isPresent = s.DOCUMENT_NOT_PRESENT, o.isNotSmall = s.DOCUMENT_TOO_FAR, o.isNotOutOfBounds = s.DOCUMENT_CENTERING, o.isSharp = s.SHARPNESS_TOO_LOW, o.isNotDim = s.BRIGHTNESS_TOO_LOW, o.isNotBright = s.BRIGHTNESS_TOO_HIGH, o.noHotspots = s.HOTSPOTS_PRESENT;
const D = o;
var d = ((t) => (t.CAMERA_PROPS_CHANGED = "document-auto-capture:camera-props-changed", t.CONTROL = "document-auto-capture:control", t.DETECTION_CHANGED = "document-auto-capture:detection-changed", t.INSTRUCTION_CHANGED = "document-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "document-auto-capture:instruction-escalated", t.STATE_CHANGED = "document-auto-capture:state-changed", t.VIDEO_ELEMENT_SIZE = "document-auto-capture:video-element-size", t))(d || {});
export {
  i as AppStateValues,
  N as ComponentCustomEvent,
  R as ControlEventInstruction,
  D as DocumentCheckToInstructionCodeMap,
  d as DocumentCustomEvent,
  s as DocumentInstructionCodeValues,
  A as EyeInstructionCodeValues,
  p as LivenessStateValues,
  S as RequestCaptureInstruction,
  m as dispatchCaptureEvent,
  I as dispatchControlEvent
};
