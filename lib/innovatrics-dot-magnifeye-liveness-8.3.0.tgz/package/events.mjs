const T = {};
T.CONTINUE_DETECTION = "continue-detection", T.SWITCH_CAMERA = "switch-camera", T.TOGGLE_MIRROR = "toggle-mirror";
const A = T, O = {};
O.FIRST_FRAME = "first-frame", O.FIRST_VALID_FRAME = "first-valid-frame";
const L = O, a = {};
a.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const R = a, c = (o, s) => {
  const E = {};
  E.detail = s, document.dispatchEvent(new CustomEvent(o, E));
}, P = (o, s) => {
  const E = {};
  E.instruction = s, c(o, E);
};
function f(o) {
  const s = {};
  s.instruction = o;
  const E = s;
  c(R.REQUEST_CAPTURE, E);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const u = n, N = { ...u };
N.DONE = "done";
const C = N, r = {};
r.EYE_NOT_PRESENT = "eye_not_present";
const i = r, e = {};
e.CANDIDATE_SELECTION = "candidate_selection", e.FACE_TOO_CLOSE = "face_too_close", e.FACE_TOO_FAR = "face_too_far", e.FACE_CENTERING = "face_centering", e.FACE_NOT_PRESENT = "face_not_present", e.SHARPNESS_TOO_LOW = "sharpness_too_low", e.BRIGHTNESS_TOO_LOW = "brightness_too_low", e.BRIGHTNESS_TOO_HIGH = "brightness_too_high", e.DEVICE_PITCHED = "device_pitched", e.LEFT_EYE_NOT_PRESENT = "left_" + i.EYE_NOT_PRESENT, e.RIGHT_EYE_NOT_PRESENT = "right_" + i.EYE_NOT_PRESENT, e.MOUTH_NOT_PRESENT = "mouth_not_present", e.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", e.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const t = e, _ = {};
_.isPresent = t.FACE_NOT_PRESENT, _.isNotPitched = t.DEVICE_PITCHED, _.isNotSmall = t.FACE_TOO_FAR, _.isNotLarge = t.FACE_TOO_CLOSE, _.isNotOutOfBounds = t.FACE_CENTERING, _.isNotDim = t.BRIGHTNESS_TOO_LOW, _.isNotBright = t.BRIGHTNESS_TOO_HIGH, _.isSharp = t.SHARPNESS_TOO_LOW, _.isLeftEyePresent = t.LEFT_EYE_NOT_PRESENT, _.isRightEyePresent = t.RIGHT_EYE_NOT_PRESENT, _.isMouthPresent = t.MOUTH_NOT_PRESENT, _.isMouthScoreNotTooHigh = t.MOUTH_SCORE_TOO_HIGH, _.isMouthScoreNotTooLow = t.MOUTH_SCORE_TOO_LOW, _.isMouthStatusNotTooHigh = t.MOUTH_SCORE_TOO_HIGH, _.isMouthStatusNotTooLow = t.MOUTH_SCORE_TOO_LOW;
const S = { ...t };
S.FIT_YOUR_EYE = "fit_your_eye";
const M = S;
var I = ((o) => (o.CLOSEUP = "CLOSEUP", o.DISTANT = "DISTANT", o.MIDDLE = "MIDDLE", o))(I || {});
const d = C;
var H = ((o) => (o.ANIMATION_END = "magnifeye-auto-capture:animation-end", o.CONTROL = "magnifeye-auto-capture:control", o.STATUS_CHANGED = "magnifeye-auto-capture:status-changed", o))(H || {});
export {
  u as AppStateValues,
  R as ComponentCustomEvent,
  A as ControlEventInstruction,
  i as EyeInstructionCodeValues,
  C as LivenessStateValues,
  H as MagnifEyeCustomEvent,
  M as MagnifEyeInstructionCodeValues,
  I as MagnifEyePhase,
  d as MagnifEyeStateValues,
  L as RequestCaptureInstruction,
  f as dispatchCaptureEvent,
  P as dispatchControlEvent
};
