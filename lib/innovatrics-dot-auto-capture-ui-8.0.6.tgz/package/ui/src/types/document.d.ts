import type { EscalatedInstructions, HTMLElementWithConfiguration } from './common';
import type { BaseUiConfiguration, InitializedBaseUiConfiguration, InitializedPlaceholderConfiguration, InitializedUiControlsConfiguration, PlaceholderConfiguration, UiControlsConfiguration } from './configuration';
import type { CustomElement, DocumentEscalatedInstructionCodes, DocumentInstructionCode, ObjectValues } from '../../../ui-common/src/types';
export * from './common';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-document-auto-capture-ui': CustomElement<{
                configuration: DocumentUiConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-document-auto-capture-ui': CustomElement<{
                configuration: DocumentUiConfiguration;
            }>;
        }
    }
}
export declare const DocumentPlaceholderIconValues: {
    readonly ID_CORNERS: "id-corners";
    readonly ID_DASH: "id-dash";
    readonly ID_DOT: "id-dot";
    readonly ID_SOLID: "id-solid";
    readonly ID_PHOTO_ROUNDED: "id-photo-rounded";
    readonly ID_CORNERS_ROUNDED: "id-corners-rounded";
    readonly ID_DASH_ROUNDED: "id-dash-rounded";
    readonly ID_DOT_ROUNDED: "id-dot-rounded";
    readonly ID_SOLID_ROUNDED_BACK: "id-solid-rounded-back";
    readonly ID_SOLID_ROUNDED: "id-solid-rounded";
    readonly PASSPORT_SOLID_BACK: "passport-solid-back";
    readonly PASSPORT_SOLID_BACK_BLANK: "passport-solid-back-blank";
};
export type DocumentPlaceholderIcon = ObjectValues<typeof DocumentPlaceholderIconValues>;
export type DocumentInstructions = Record<DocumentInstructionCode, string>;
export type DocumentUiConfiguration = BaseUiConfiguration<Partial<DocumentInstructions>, UiControlsConfiguration> & PlaceholderConfiguration<DocumentPlaceholderIcon> & EscalatedInstructions<DocumentEscalatedInstructionCodes>;
export type InitializedDocumentUiConfiguration = InitializedBaseUiConfiguration<DocumentInstructions, InitializedUiControlsConfiguration> & InitializedPlaceholderConfiguration<DocumentPlaceholderIcon> & EscalatedInstructions<DocumentEscalatedInstructionCodes>;
export type HTMLDocumentUiElement = HTMLElementWithConfiguration<DocumentUiConfiguration>;
