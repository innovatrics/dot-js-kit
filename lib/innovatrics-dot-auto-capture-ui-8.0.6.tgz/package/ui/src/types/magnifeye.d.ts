import type { AppStateInstruction, HTMLElementWithConfiguration } from './common';
import type { BaseUiConfiguration, ButtonControlsConfiguration, InitializedBaseUiConfiguration, InitializedButtonControlsConfiguration } from './configuration';
import type { CustomElement, DeepRequired, MagnifEyeInstructionCode } from '../../../ui-common/src/types';
export * from './common';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-magnifeye-liveness-ui': CustomElement<{
                configuration: MagnifEyeLivenessUiConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-magnifeye-liveness-ui': CustomElement<{
                configuration: MagnifEyeLivenessUiConfiguration;
            }>;
        }
    }
}
export type MagnifEyeInstructions = Record<MagnifEyeInstructionCode, string>;
export type CustomizableMagnifEyeInstructions = Omit<MagnifEyeInstructions, 'mouth_score_too_high' | 'mouth_score_too_low'>;
export type MagnifEyeLivenessUiConfiguration = BaseUiConfiguration<CustomizableMagnifEyeInstructions, ButtonControlsConfiguration, MagnifEyeStateInstructions>;
export type InitializedMagnifEyeLivenessUiConfiguration = InitializedBaseUiConfiguration<MagnifEyeInstructions, InitializedButtonControlsConfiguration, UiMagnifEyeStateInstructions>;
export type HTMLMagnifEyeLivenessUiElement = HTMLElementWithConfiguration<MagnifEyeLivenessUiConfiguration>;
export type MagnifEyeStateInstructions = {
    done?: AppStateInstruction;
    loading?: AppStateInstruction;
};
export type UiMagnifEyeStateInstructions = {
    [key: string]: DeepRequired<AppStateInstruction>;
};
