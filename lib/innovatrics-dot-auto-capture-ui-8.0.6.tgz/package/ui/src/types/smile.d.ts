import type { EscalatedInstructions, HTMLElementWithConfiguration, UiAppStateInstructions } from './common';
import type { BaseUiConfiguration, ButtonControlsConfiguration, InitializedBaseUiConfiguration, InitializedButtonControlsConfiguration, InitializedPlaceholderConfiguration, PlaceholderConfiguration } from './configuration';
import type { CustomElement, SmileEscalatedInstructionCodes, SmileInstructionCode } from '../../../ui-common/src/types';
export * from './common';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-smile-liveness-ui': CustomElement<{
                configuration: SmileLivenessUiConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-smile-liveness-ui': CustomElement<{
                configuration: SmileLivenessUiConfiguration;
            }>;
        }
    }
}
export type SmileInstructions = Record<SmileInstructionCode, string>;
export type CustomizableSmileInstructions = Omit<SmileInstructions, 'mouth_score_too_high' | 'mouth_score_too_low'>;
export type SmileLivenessUiConfiguration = BaseUiConfiguration<CustomizableSmileInstructions, ButtonControlsConfiguration, UiAppStateInstructions> & PlaceholderConfiguration<string> & EscalatedInstructions<SmileEscalatedInstructionCodes>;
export type InitializedSmileLivenessUiConfiguration = InitializedBaseUiConfiguration<SmileInstructions, InitializedButtonControlsConfiguration, UiAppStateInstructions> & InitializedPlaceholderConfiguration<string> & EscalatedInstructions<SmileEscalatedInstructionCodes>;
export type HTMLSmileLivenessUiElement = HTMLElementWithConfiguration<SmileLivenessUiConfiguration>;
