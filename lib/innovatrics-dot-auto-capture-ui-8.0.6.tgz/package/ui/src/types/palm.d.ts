import type { HTMLElementWithConfiguration } from './common';
import type { BaseUiConfiguration, InitializedBaseUiConfiguration, InitializedPlaceholderConfiguration, InitializedUiControlsConfiguration, PlaceholderConfiguration, UiControlsConfiguration } from './configuration';
import type { CustomElement, ObjectValues, PalmInstructionCode } from '../../../ui-common/src/types';
export * from './common';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-palm-capture-ui': CustomElement<{
                configuration: PalmUiConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-palm-capture-ui': CustomElement<{
                configuration: PalmUiConfiguration;
            }>;
        }
    }
}
export declare const PalmPlaceholderIconValues: {
    readonly LEFT: "left";
    readonly RIGHT: "right";
};
export type PalmPlaceholderIcon = ObjectValues<typeof PalmPlaceholderIconValues>;
export type PalmInstructions = Record<PalmInstructionCode, string>;
export type PalmUiConfiguration = BaseUiConfiguration<Partial<PalmInstructions>, UiControlsConfiguration> & PlaceholderConfiguration<PalmPlaceholderIcon>;
export type InitializedPalmUiConfiguration = InitializedBaseUiConfiguration<PalmInstructions, InitializedUiControlsConfiguration> & InitializedPlaceholderConfiguration<PalmPlaceholderIcon>;
export type HTMLPalmUiElement = HTMLElementWithConfiguration<PalmUiConfiguration>;
