import type { DeepRequired } from '../../../ui-common/src/types';
import type { CSSProperties } from 'styled-components';
export type AutoCaptureTheme = {
    colors: {
        instructionColor: string;
        instructionColorSuccess: string;
        instructionTextColor: string;
        placeholderColor: string;
        placeholderColorSuccess: string;
    };
    font: {
        family: CSSProperties['fontFamily'];
        minimumSize: number;
        style: CSSProperties['fontStyle'];
        weight: CSSProperties['fontWeight'];
    };
};
export type AppStateInstruction = {
    text?: string;
    visible?: boolean;
};
export type AppStateInstructions = {
    loading?: AppStateInstruction;
    waiting?: AppStateInstruction;
};
export type UiAppStateInstructions = {
    [key: string]: DeepRequired<AppStateInstruction>;
};
export type EscalatedInstructions<I extends string> = {
    escalatedInstructions?: Partial<Record<I, string>>;
};
export type CameraButtonIconProps = {
    size: number;
};
export type HTMLElementWithConfiguration<P> = HTMLElement & {
    configuration: P;
};
