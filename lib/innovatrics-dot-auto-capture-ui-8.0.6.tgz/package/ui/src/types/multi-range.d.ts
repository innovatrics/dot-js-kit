import type { EscalatedInstructions, HTMLElementWithConfiguration, UiAppStateInstructions } from './common';
import type { BaseUiConfiguration, InitializedBaseUiConfiguration, InitializedPlaceholderConfiguration, InitializedUiControlsConfiguration, PlaceholderConfiguration, UiControlsConfiguration } from './configuration';
import type { CustomElement, MultiRangeEscalatedInstructionCodes, MultiRangeInstructionCode, ObjectValues } from '../../../ui-common/src/types';
export * from './common';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-multi-range-liveness-ui': CustomElement<{
                configuration: MultiRangeUiConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-multi-range-liveness-ui': CustomElement<{
                configuration: MultiRangeUiConfiguration;
            }>;
        }
    }
}
export declare const MultiRangePlaceholderIconValues: {
    readonly CIRCLE_SOLID: "circle-solid";
};
export type MultiRangePlaceholderIcon = ObjectValues<typeof MultiRangePlaceholderIconValues>;
export type MultiRangeInstructions = Record<MultiRangeInstructionCode, string>;
export type MultiRangeUiConfiguration = BaseUiConfiguration<MultiRangeInstructions, UiControlsConfiguration, UiAppStateInstructions> & PlaceholderConfiguration<MultiRangePlaceholderIcon> & EscalatedInstructions<MultiRangeEscalatedInstructionCodes>;
export type InitializedMultiRangeUiConfiguration = InitializedBaseUiConfiguration<MultiRangeInstructions, InitializedUiControlsConfiguration, UiAppStateInstructions> & InitializedPlaceholderConfiguration<MultiRangePlaceholderIcon> & EscalatedInstructions<MultiRangeEscalatedInstructionCodes>;
export type HTMLMultiRangeLivenessUiElement = HTMLElementWithConfiguration<MultiRangeUiConfiguration>;
