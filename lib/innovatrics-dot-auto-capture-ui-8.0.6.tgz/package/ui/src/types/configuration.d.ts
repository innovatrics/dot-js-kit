import type { AppStateInstructions } from './common';
import type { DeepPartial, RequireSome } from '../../../ui-common/src/types/common';
import type { CSSProperties } from 'styled-components';
export type AutoCaptureTheme = {
    colors: {
        instructionColor: string;
        instructionColorSuccess: string;
        instructionTextColor: string;
        placeholderColor: string;
        placeholderColorSuccess: string;
    };
    font: {
        family: CSSProperties['fontFamily'];
        minimumSize: number;
        style: CSSProperties['fontStyle'];
        weight: CSSProperties['fontWeight'];
    };
};
export type ButtonControlsConfiguration = {
    showCameraButtons?: boolean;
};
export type DetectionLayerControlsConfiguration = {
    showDetectionLayer?: boolean;
};
export type UiControlsConfiguration = ButtonControlsConfiguration & DetectionLayerControlsConfiguration;
type StylingConfiguration = {
    backdropColor?: string;
    theme?: DeepPartial<AutoCaptureTheme>;
};
type InstructionsConfiguration<TInstructions, TAppStateInstructions = AppStateInstructions> = {
    appStateInstructions?: TAppStateInstructions;
    instructions?: Partial<TInstructions>;
};
export type PlaceholderConfiguration<TPlaceholder> = {
    placeholder?: TPlaceholder;
};
export type BaseUiConfiguration<TInstructions, TControls = ButtonControlsConfiguration, TAppStateInstructions = AppStateInstructions> = InstructionsConfiguration<TInstructions, TAppStateInstructions> & {
    control?: TControls;
    styleTarget?: HTMLElement;
    styling?: StylingConfiguration;
};
export type InitializedButtonControlsConfiguration = Required<ButtonControlsConfiguration>;
export type InitializedDetectionLayerControlsConfiguration = Required<DetectionLayerControlsConfiguration>;
export type InitializedUiControlsConfiguration = InitializedButtonControlsConfiguration & InitializedDetectionLayerControlsConfiguration;
export type InitializedUiStylingConfiguration = RequireSome<StylingConfiguration, 'backdropColor'> & {
    theme: AutoCaptureTheme;
};
export type InitializedUiInstructionsConfiguration<TInstructions, TAppStateInstructions = AppStateInstructions> = {
    appStateInstructions: TAppStateInstructions;
    instructions: TInstructions;
};
export type InitializedPlaceholderConfiguration<TPlaceholder> = {
    placeholder: TPlaceholder;
};
export type InitializedBaseUiConfiguration<TInstructions, TControls = InitializedButtonControlsConfiguration, TAppStateInstructions = AppStateInstructions> = InitializedUiInstructionsConfiguration<TInstructions, TAppStateInstructions> & {
    control: TControls;
    styleTarget?: HTMLElement;
    styling: InitializedUiStylingConfiguration;
};
export {};
