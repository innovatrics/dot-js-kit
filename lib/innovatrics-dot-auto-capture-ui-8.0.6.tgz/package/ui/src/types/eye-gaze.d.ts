import type { AppStateInstruction, HTMLElementWithConfiguration } from './common';
import type { BaseUiConfiguration, ButtonControlsConfiguration, InitializedBaseUiConfiguration, InitializedButtonControlsConfiguration, InitializedPlaceholderConfiguration } from './configuration';
import type { CornerValues, CustomElement, DeepRequired, EyeGazeInstructionCode } from '../../../ui-common/src/types';
export * from './common';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-eye-gaze-liveness-ui': CustomElement<{
                configuration: EyeGazeLivenessUiConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-eye-gaze-liveness-ui': CustomElement<{
                configuration: EyeGazeLivenessUiConfiguration;
            }>;
        }
    }
}
export type EyeGazeInstructions = Record<EyeGazeInstructionCode, string>;
type CustomizableInstructions = Omit<EyeGazeInstructions, 'mouth_score_too_high' | 'mouth_score_too_low'>;
export type EyeGazeLivenessUiConfiguration = BaseUiConfiguration<CustomizableInstructions, ButtonControlsConfiguration, EyeGazeStateInstructions> & {
    collectionPhasePlaceholder?: string;
    corners: Array<CornerValues>;
};
export type InitializedEyeGazeLivenessUiConfiguration = InitializedBaseUiConfiguration<EyeGazeInstructions, InitializedButtonControlsConfiguration, UiEyeGazeStateInstructions> & InitializedPlaceholderConfiguration<string> & {
    collectionPhasePlaceholder?: string;
    corners: Array<CornerValues>;
};
export type HTMLEyeGazeLivenessUiElement = HTMLElementWithConfiguration<EyeGazeLivenessUiConfiguration>;
export type EyeGazeStateInstructions = {
    done?: AppStateInstruction;
    loading?: AppStateInstruction;
};
export type UiEyeGazeStateInstructions = {
    [key: string]: DeepRequired<AppStateInstruction>;
};
