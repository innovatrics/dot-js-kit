import type { HTMLElementWithConfiguration } from './common';
import type { BaseUiConfiguration, InitializedBaseUiConfiguration, InitializedPlaceholderConfiguration, InitializedUiControlsConfiguration, PlaceholderConfiguration, UiControlsConfiguration } from './configuration';
import type { CustomElement, FaceInstructionCode, ObjectValues } from '../../../ui-common/src/types';
export * from './common';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-face-auto-capture-ui': CustomElement<{
                configuration: FaceUiConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-face-auto-capture-ui': CustomElement<{
                configuration: FaceUiConfiguration;
            }>;
        }
    }
}
export declare const FacePlaceholderIconValues: {
    readonly CIRCLE_SOLID: "circle-solid";
    readonly SQUARE_ROUNDED_DASH: "square-rounded-dash";
    readonly SQUARE_ROUNDED_SOLID: "square-rounded-solid";
    readonly SQUARE_DASH: "square-dash";
    readonly SQUARE_SOLID: "square-solid";
};
export type FacePlaceholderIcon = ObjectValues<typeof FacePlaceholderIconValues>;
export type FaceInstructions = Record<FaceInstructionCode, string>;
export type CustomizableFaceInstructions = Omit<FaceInstructions, 'mouth_score_too_low' | 'mouth_score_too_high'>;
export type FaceUiConfiguration<I = CustomizableFaceInstructions> = BaseUiConfiguration<I, UiControlsConfiguration> & PlaceholderConfiguration<FacePlaceholderIcon>;
export type InitializedFaceUiConfiguration = InitializedBaseUiConfiguration<FaceInstructions, InitializedUiControlsConfiguration> & InitializedPlaceholderConfiguration<FacePlaceholderIcon>;
export type HTMLFacetUiElement = HTMLElementWithConfiguration<FaceUiConfiguration>;
