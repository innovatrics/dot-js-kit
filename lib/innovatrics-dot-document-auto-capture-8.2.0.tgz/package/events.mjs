const _ = {};
_.CONTINUE_DETECTION = "continue-detection", _.SWITCH_CAMERA = "switch-camera", _.TOGGLE_MIRROR = "toggle-mirror";
const S = _, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const d = T, u = {};
u.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const N = u, a = (t, E) => {
  const n = {};
  n.detail = E, document.dispatchEvent(new CustomEvent(t, n));
}, I = (t, E) => {
  const n = {};
  n.instruction = E, a(t, n);
};
function m(t) {
  const E = {};
  E.instruction = t;
  const n = E;
  a(N.REQUEST_CAPTURE, n);
}
const c = {};
c.LOADING = "loading", c.ERROR = "error", c.WAITING = "waiting", c.RUNNING = "running", c.COMPLETE = "complete", c.BLURRED = "blurred";
const i = c, r = { ...i };
r.DONE = "done";
const p = r, O = {};
O.EYE_NOT_PRESENT = "eye_not_present";
const A = O, o = {};
o.CANDIDATE_SELECTION = "candidate_selection", o.DOCUMENT_CENTERING = "document_centering", o.DOCUMENT_NOT_PRESENT = "document_not_present", o.DOCUMENT_TOO_FAR = "document_too_far", o.SHARPNESS_TOO_LOW = "sharpness_too_low", o.BRIGHTNESS_TOO_LOW = "brightness_too_low", o.BRIGHTNESS_TOO_HIGH = "brightness_too_high", o.HOTSPOTS_PRESENT = "hotspots_present";
const s = o, e = {};
e.isPresent = s.DOCUMENT_NOT_PRESENT, e.isNotSmall = s.DOCUMENT_TOO_FAR, e.isNotOutOfBounds = s.DOCUMENT_CENTERING, e.isSharp = s.SHARPNESS_TOO_LOW, e.isNotDim = s.BRIGHTNESS_TOO_LOW, e.isNotBright = s.BRIGHTNESS_TOO_HIGH, e.noHotspots = s.HOTSPOTS_PRESENT;
const D = e;
var C = ((t) => (t.CAMERA_PROPS_CHANGED = "document-auto-capture:camera-props-changed", t.CONTROL = "document-auto-capture:control", t.DETECTION_CHANGED = "document-auto-capture:detection-changed", t.INSTRUCTION_CHANGED = "document-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "document-auto-capture:instruction-escalated", t.STATE_CHANGED = "document-auto-capture:state-changed", t.VIDEO_ELEMENT_SIZE = "document-auto-capture:video-element-size", t))(C || {});
export {
  i as AppStateValues,
  N as ComponentCustomEvent,
  S as ControlEventInstruction,
  D as DocumentCheckToInstructionCodeMap,
  C as DocumentCustomEvent,
  s as DocumentInstructionCodeValues,
  A as EyeInstructionCodeValues,
  p as LivenessStateValues,
  d as RequestCaptureInstruction,
  m as dispatchCaptureEvent,
  I as dispatchControlEvent
};
