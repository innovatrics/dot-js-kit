const T = {};
T.CONTINUE_DETECTION = "continue-detection", T.SWITCH_CAMERA = "switch-camera", T.TOGGLE_MIRROR = "toggle-mirror";
const h = T, O = {};
O.FIRST_FRAME = "first-frame", O.FIRST_VALID_FRAME = "first-valid-frame";
const H = O, i = {};
i.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const R = i, a = (t, n) => {
  const E = {};
  E.detail = n, document.dispatchEvent(new CustomEvent(t, E));
}, P = (t, n) => {
  const E = {};
  E.instruction = n, a(t, E);
};
function L(t) {
  const n = {};
  n.instruction = t;
  const E = n;
  a(R.REQUEST_CAPTURE, E);
}
const s = {};
s.LOADING = "loading", s.ERROR = "error", s.WAITING = "waiting", s.RUNNING = "running", s.COMPLETE = "complete";
const u = s, N = { ...u };
N.DONE = "done";
const C = N, r = {};
r.EYE_NOT_PRESENT = "eye_not_present";
const c = r, e = {};
e.CANDIDATE_SELECTION = "candidate_selection", e.FACE_TOO_CLOSE = "face_too_close", e.FACE_TOO_FAR = "face_too_far", e.FACE_CENTERING = "face_centering", e.FACE_NOT_PRESENT = "face_not_present", e.SHARPNESS_TOO_LOW = "sharpness_too_low", e.BRIGHTNESS_TOO_LOW = "brightness_too_low", e.BRIGHTNESS_TOO_HIGH = "brightness_too_high", e.DEVICE_PITCHED = "device_pitched", e.LEFT_EYE_NOT_PRESENT = "left_" + c.EYE_NOT_PRESENT, e.RIGHT_EYE_NOT_PRESENT = "right_" + c.EYE_NOT_PRESENT, e.MOUTH_NOT_PRESENT = "mouth_not_present", e.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", e.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const _ = e, o = {};
o.isPresent = _.FACE_NOT_PRESENT, o.isNotPitched = _.DEVICE_PITCHED, o.isNotSmall = _.FACE_TOO_FAR, o.isNotLarge = _.FACE_TOO_CLOSE, o.isNotOutOfBounds = _.FACE_CENTERING, o.isNotDim = _.BRIGHTNESS_TOO_LOW, o.isNotBright = _.BRIGHTNESS_TOO_HIGH, o.isSharp = _.SHARPNESS_TOO_LOW, o.isLeftEyePresent = _.LEFT_EYE_NOT_PRESENT, o.isRightEyePresent = _.RIGHT_EYE_NOT_PRESENT, o.isMouthPresent = _.MOUTH_NOT_PRESENT, o.isMouthScoreNotTooHigh = _.MOUTH_SCORE_TOO_HIGH, o.isMouthScoreNotTooLow = _.MOUTH_SCORE_TOO_LOW;
const S = { ..._ };
S.FIT_YOUR_EYE = "fit_your_eye";
const d = S;
var I = ((t) => (t.CLOSEUP = "CLOSEUP", t.DISTANT = "DISTANT", t.MIDDLE = "MIDDLE", t))(I || {});
const g = C;
var A = ((t) => (t.ANIMATION_END = "magnifeye-auto-capture:animation-end", t.CONTROL = "magnifeye-auto-capture:control", t.STATUS_CHANGED = "magnifeye-auto-capture:status-changed", t))(A || {});
export {
  u as AppStateValues,
  R as ComponentCustomEvent,
  h as ControlEventInstruction,
  c as EyeInstructionCodeValues,
  C as LivenessStateValues,
  A as MagnifEyeCustomEvent,
  d as MagnifEyeInstructionCodeValues,
  I as MagnifEyePhase,
  g as MagnifEyeStateValues,
  H as RequestCaptureInstruction,
  L as dispatchCaptureEvent,
  P as dispatchControlEvent
};
