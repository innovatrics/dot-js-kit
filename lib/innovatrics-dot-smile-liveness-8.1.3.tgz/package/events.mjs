const s = {};
s.CONTINUE_DETECTION = "continue-detection", s.SWITCH_CAMERA = "switch-camera", s.TOGGLE_MIRROR = "toggle-mirror";
const R = s, a = {};
a.FIRST_FRAME = "first-frame", a.FIRST_VALID_FRAME = "first-valid-frame";
const p = a, E = {};
E.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const _ = E, i = (c, o) => {
  const e = {};
  e.detail = o, document.dispatchEvent(new CustomEvent(c, e));
}, d = (c, o) => {
  const e = {};
  e.instruction = o, i(c, e);
};
function l(c) {
  const o = {};
  o.instruction = c;
  const e = o;
  i(_.REQUEST_CAPTURE, e);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const C = n, u = { ...C };
u.DONE = "done";
const m = u, r = {};
r.EYE_NOT_PRESENT = "eye_not_present";
const N = r, t = {};
t.DETECTION_CHANGED = "smile-auto-capture:detection-changed", t.CAMERA_PROPS_CHANGED = "smile-auto-capture:camera-props-changed", t.CONTROL = "smile-auto-capture:control", t.INSTRUCTION_CHANGED = "smile-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "smile-auto-capture:instruction-escalated", t.VIDEO_ELEMENT_SIZE = "smile-auto-capture:video-element-size", t.STATE_CHANGED = "smile-auto-capture:state-changed", t.PHASE_CHANGED = "smile-auto-capture:phase-changed";
const A = t;
export {
  C as AppStateValues,
  _ as ComponentCustomEvent,
  R as ControlEventInstruction,
  N as EyeInstructionCodeValues,
  m as LivenessStateValues,
  p as RequestCaptureInstruction,
  A as SmileCustomEvent,
  l as dispatchCaptureEvent,
  d as dispatchControlEvent
};
