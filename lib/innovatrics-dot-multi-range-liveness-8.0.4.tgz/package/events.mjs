const c = {};
c.CONTINUE_DETECTION = "continue-detection", c.SWITCH_CAMERA = "switch-camera", c.TOGGLE_MIRROR = "toggle-mirror";
const T = c, s = {};
s.FIRST_FRAME = "first-frame", s.FIRST_VALID_FRAME = "first-valid-frame";
const d = s, u = {};
u.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const _ = u, E = (a, n) => {
  const e = {};
  e.detail = n, document.dispatchEvent(new CustomEvent(a, e));
}, p = (a, n) => {
  const e = {};
  e.instruction = n, E(a, e);
};
function N(a) {
  const n = {};
  n.instruction = a;
  const e = n;
  E(_.REQUEST_CAPTURE, e);
}
const o = {};
o.LOADING = "loading", o.ERROR = "error", o.WAITING = "waiting", o.RUNNING = "running", o.COMPLETE = "complete";
const C = o, r = { ...C };
r.DONE = "done";
const A = r, i = {};
i.EYE_NOT_PRESENT = "eye_not_present";
const R = i, t = {};
t.DETECTION_CHANGED = "multi-range-auto-capture:detection-changed", t.CAMERA_PROPS_CHANGED = "multi-range-auto-capture:camera-props-changed", t.CONTROL = "multi-range-auto-capture:control", t.PHASE_CHANGED = "multi-range-auto-capture:phase-changed", t.INSTRUCTION_CHANGED = "multi-range-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "multi-range-auto-capture:instruction-escalated", t.VIDEO_ELEMENT_SIZE = "multi-range-auto-capture:video-element-size", t.CHALLENGE_VALUE_CHANGED = "multi-range-auto-capture:challenge-value-changed", t.STATE_CHANGED = "multi-range-auto-capture:state-changed";
const m = t;
export {
  C as AppStateValues,
  _ as ComponentCustomEvent,
  T as ControlEventInstruction,
  R as EyeInstructionCodeValues,
  A as LivenessStateValues,
  m as MultiRangeCustomEvent,
  d as RequestCaptureInstruction,
  N as dispatchCaptureEvent,
  p as dispatchControlEvent
};
