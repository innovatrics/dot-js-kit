const _ = {};
_.CONTINUE_DETECTION = "continue-detection", _.SWITCH_CAMERA = "switch-camera", _.TOGGLE_MIRROR = "toggle-mirror";
const R = _, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const S = T, u = {};
u.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const N = u, a = (t, c) => {
  const e = {};
  e.detail = c, document.dispatchEvent(new CustomEvent(t, e));
}, I = (t, c) => {
  const e = {};
  e.instruction = c, a(t, e);
};
function m(t) {
  const c = {};
  c.instruction = t;
  const e = c;
  a(N.REQUEST_CAPTURE, e);
}
const E = {};
E.LOADING = "loading", E.ERROR = "error", E.WAITING = "waiting", E.RUNNING = "running", E.COMPLETE = "complete", E.BLURRED = "blurred";
const i = E, r = { ...i };
r.DONE = "done";
const p = r, O = {};
O.EYE_NOT_PRESENT = "eye_not_present";
const A = O, o = {};
o.CANDIDATE_SELECTION = "candidate_selection", o.DOCUMENT_CENTERING = "document_centering", o.DOCUMENT_NOT_PRESENT = "document_not_present", o.DOCUMENT_TOO_FAR = "document_too_far", o.SHARPNESS_TOO_LOW = "sharpness_too_low", o.BRIGHTNESS_TOO_LOW = "brightness_too_low", o.BRIGHTNESS_TOO_HIGH = "brightness_too_high", o.HOTSPOTS_PRESENT = "hotspots_present";
const s = o, n = {};
n.isPresent = s.DOCUMENT_NOT_PRESENT, n.isNotSmall = s.DOCUMENT_TOO_FAR, n.isNotOutOfBounds = s.DOCUMENT_CENTERING, n.isSharp = s.SHARPNESS_TOO_LOW, n.isNotDim = s.BRIGHTNESS_TOO_LOW, n.isNotBright = s.BRIGHTNESS_TOO_HIGH, n.noHotspots = s.HOTSPOTS_PRESENT;
const D = n;
var C = ((t) => (t.CAMERA_PROPS_CHANGED = "document-auto-capture:camera-props-changed", t.CONTROL = "document-auto-capture:control", t.DETECTION_CHANGED = "document-auto-capture:detection-changed", t.INSTRUCTION_CHANGED = "document-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "document-auto-capture:instruction-escalated", t.STATE_CHANGED = "document-auto-capture:state-changed", t.VIDEO_ELEMENT_SIZE = "document-auto-capture:video-element-size", t))(C || {});
export {
  i as AppStateValues,
  N as ComponentCustomEvent,
  R as ControlEventInstruction,
  D as DocumentCheckToInstructionCodeMap,
  C as DocumentCustomEvent,
  s as DocumentInstructionCodeValues,
  A as EyeInstructionCodeValues,
  p as LivenessStateValues,
  S as RequestCaptureInstruction,
  m as dispatchCaptureEvent,
  I as dispatchControlEvent
};
