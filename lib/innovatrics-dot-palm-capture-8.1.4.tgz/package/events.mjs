const c = {};
c.CONTINUE_DETECTION = "continue-detection", c.SWITCH_CAMERA = "switch-camera", c.TOGGLE_MIRROR = "toggle-mirror";
const l = c, a = {};
a.FIRST_FRAME = "first-frame", a.FIRST_VALID_FRAME = "first-valid-frame";
const p = a, T = {};
T.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const N = T, i = (t, s) => {
  const _ = {};
  _.detail = s, document.dispatchEvent(new CustomEvent(t, _));
}, R = (t, s) => {
  const _ = {};
  _.instruction = s, i(t, _);
};
function A(t) {
  const s = {};
  s.instruction = t;
  const _ = s;
  i(N.REQUEST_CAPTURE, _);
}
const E = {};
E.LOADING = "loading", E.ERROR = "error", E.WAITING = "waiting", E.RUNNING = "running", E.COMPLETE = "complete", E.BLURRED = "blurred";
const C = E, r = { ...C };
r.DONE = "done";
const d = r, O = {};
O.EYE_NOT_PRESENT = "eye_not_present";
const S = O, o = {};
o.CANDIDATE_SELECTION = "candidate_selection", o.PALM_CENTERING = "palm_centering", o.PALM_NOT_PRESENT = "palm_not_present", o.PALM_TOO_FAR = "palm_too_far", o.PALM_TOO_CLOSE = "palm_too_close", o.SHARPNESS_TOO_LOW = "sharpness_too_low", o.BRIGHTNESS_TOO_LOW = "brightness_too_low", o.BRIGHTNESS_TOO_HIGH = "brightness_too_high", o.DEVICE_PITCHED = "device_pitched", o.TEMPLATE_EXTRACTION_QUALITY_TOO_LOW = "template_extraction_quality_too_low";
const e = o, n = {};
n.isPresent = e.PALM_NOT_PRESENT, n.isNotPitched = e.DEVICE_PITCHED, n.isNotSmall = e.PALM_TOO_FAR, n.isNotOutOfBounds = e.PALM_CENTERING, n.isNotDim = e.BRIGHTNESS_TOO_LOW, n.isNotBright = e.BRIGHTNESS_TOO_HIGH, n.isSharp = e.SHARPNESS_TOO_LOW, n.isNotLarge = e.PALM_TOO_CLOSE, n.isTemplateExtractionQualityHighEnough = e.TEMPLATE_EXTRACTION_QUALITY_TOO_LOW;
const m = n;
var u = ((t) => (t.CAMERA_PROPS_CHANGED = "palm-capture:camera-props-changed", t.CONTROL = "palm-capture:control", t.DETECTION_CHANGED = "palm-capture:detection-changed", t.INSTRUCTION_CHANGED = "palm-capture:instruction-changed", t.STATE_CHANGED = "palm-capture:state-changed", t.VIDEO_ELEMENT_SIZE = "palm-capture:video-element-size", t))(u || {});
export {
  C as AppStateValues,
  N as ComponentCustomEvent,
  l as ControlEventInstruction,
  S as EyeInstructionCodeValues,
  d as LivenessStateValues,
  m as PalmCheckToInstructionCodeMap,
  u as PalmCustomEvent,
  e as PalmInstructionCodeValues,
  p as RequestCaptureInstruction,
  A as dispatchCaptureEvent,
  R as dispatchControlEvent
};
