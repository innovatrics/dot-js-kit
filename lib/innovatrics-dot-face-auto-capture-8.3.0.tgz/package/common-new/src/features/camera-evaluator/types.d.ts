import type { DEFAULT_OPTIONS } from './constants';
export type TestParameters = {
    abortAfterMs?: number;
    fallbackConstraints: MediaTrackConstraints;
    maxTestDuration: number;
    primaryConstraints: MediaTrackConstraints;
    runAmount: number;
    runDurationCutoffFactor: number;
};
export type RunResult = {
    average: number;
    deviceId?: string;
};
export type SingleIterationRunResult = {
    deviceId?: string;
    duration?: number;
    error?: Error;
};
export type EvaluationOptionsKeys = keyof typeof DEFAULT_OPTIONS;
export type CameraData = {
    cameraName?: string;
    fastAvg: number;
    slowAvg: number;
};
