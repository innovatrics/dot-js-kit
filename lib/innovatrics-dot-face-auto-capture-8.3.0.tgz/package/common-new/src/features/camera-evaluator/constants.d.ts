export declare const MAX_FAST_TEST_DURATION = 2500;
export declare const MAX_SLOW_TEST_DURATION = 3500;
export declare const RUN_AMOUNT = 2;
export declare const RUN_DURATION_CUTOFF_FACTOR = 0.5;
export declare const VIDEO_CONSTRAINTS: {
    readonly fast: {
        readonly width: {
            readonly exact: 1920;
        };
        readonly height: {
            readonly exact: 1080;
        };
        readonly frameRate: {
            readonly exact: 30;
        };
    };
    readonly safeFast: {
        readonly width: {
            readonly ideal: 1920;
        };
        readonly height: {
            readonly ideal: 1080;
        };
        readonly frameRate: 30;
    };
    readonly slow: {
        readonly width: {
            readonly exact: 1;
        };
        readonly height: {
            readonly exact: 1;
        };
        readonly frameRate: {
            readonly exact: 1;
        };
    };
    readonly safeSlow: {
        readonly width: {
            readonly ideal: 1;
        };
        readonly height: {
            readonly ideal: 1;
        };
        readonly frameRate: {
            readonly ideal: 1;
        };
    };
};
export declare const DEFAULT_OPTIONS: {
    readonly fast: {
        readonly maxTestDuration: 2500;
        readonly primaryConstraints: {
            readonly width: {
                readonly exact: 1920;
            };
            readonly height: {
                readonly exact: 1080;
            };
            readonly frameRate: {
                readonly exact: 30;
            };
        };
        readonly fallbackConstraints: {
            readonly width: {
                readonly ideal: 1920;
            };
            readonly height: {
                readonly ideal: 1080;
            };
            readonly frameRate: 30;
        };
        readonly runAmount: 2;
        readonly runDurationCutoffFactor: 0.5;
        readonly abortAfterMs: 2500;
    };
    readonly slow: {
        readonly maxTestDuration: 3500;
        readonly primaryConstraints: {
            readonly width: {
                readonly exact: 1;
            };
            readonly height: {
                readonly exact: 1;
            };
            readonly frameRate: {
                readonly exact: 1;
            };
        };
        readonly fallbackConstraints: {
            readonly width: {
                readonly ideal: 1;
            };
            readonly height: {
                readonly ideal: 1;
            };
            readonly frameRate: {
                readonly ideal: 1;
            };
        };
        readonly runAmount: 2;
        readonly runDurationCutoffFactor: 0.5;
        readonly abortAfterMs: 3500;
    };
};
