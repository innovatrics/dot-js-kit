import type { RawDetectedSamObject, RawImageParameters } from '../common';
export type RawDetectedDocument = RawDetectedSamObject & {
    params: RawImageParameters;
};
