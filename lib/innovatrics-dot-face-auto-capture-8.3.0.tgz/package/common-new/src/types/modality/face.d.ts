import type { DetectionDetails, RawImageParameters } from '../common';
import type { MinInterval } from '../../../../ui-common/src/types/index.js';
import type { FaceInstructionCode } from '../../../../ui-common/src/types/face.js';
import type { DetectedFace } from '../../../../ui-common/src/types/modality/detection/face.js';
export type EyeThresholds = {
    confidence: MinInterval;
};
export type MouthThresholds = {
    confidence: MinInterval;
    status: {
        max: number;
        min?: number;
    } | {
        max?: number;
        min: number;
    };
};
export type RawDetectedFacePart = {
    centerX: number;
    centerY: number;
    confidence: number;
    size: number;
    status: number;
};
export type RawDetectedFace = {
    bottomRightX: number;
    bottomRightY: number;
    confidence: number;
    leftEye: RawDetectedFacePart;
    mouth: RawDetectedFacePart;
    params: RawImageParameters;
    rightEye: RawDetectedFacePart;
    topLeftX: number;
    topLeftY: number;
    yaw: number;
};
export type FaceDetectionDetails = DetectionDetails<DetectedFace, FaceInstructionCode>;
