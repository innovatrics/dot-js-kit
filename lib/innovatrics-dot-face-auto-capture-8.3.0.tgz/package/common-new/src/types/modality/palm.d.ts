import type { EmscriptenEnum, RawDetectedSamObject, RawImageParameters } from '../common';
export type RawDetectedPalm = RawDetectedSamObject & {
    params: RawImageParameters;
};
export declare const PalmHandPositionMap: {
    readonly 0: "Left";
    readonly 1: "Right";
};
export declare const PalmHandOrientationMap: {
    readonly 0: "Palmar";
    readonly 1: "Dorsal";
};
export type RawPalmAttributes = {
    handOrientation: EmscriptenEnum<number>;
    handPosition: EmscriptenEnum<number>;
    quality: number;
};
export type RawDetectedPalmWithAttributes = {
    rawDetectedPalm: RawDetectedPalm;
    rawPalmAttributes: RawPalmAttributes;
};
