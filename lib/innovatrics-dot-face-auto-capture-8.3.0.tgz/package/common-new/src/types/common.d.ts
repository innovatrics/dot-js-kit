import type { RawDetectedDocument } from './modality/document';
import type { RawDetectedFace } from './modality/face';
import type { RawDetectedPalm, RawPalmAttributes } from './modality/palm';
import type { CameraData } from '../features/camera-evaluator/types';
import type { dot } from '@dot/proto-files';
import type { ImageParameters, ObjectValues, Resolution } from '../../../ui-common/src/types/common.js';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
}
export declare const ImageFormat: {
    readonly RGB: "RGB";
    readonly RGBA: "RGBA";
};
export declare const InstructionSet: {
    readonly SIMD: "simd";
    readonly NO_SIMD: "no-simd";
};
export type SamWasmModule = {
    _free(memoryPointer: number): void;
    _malloc(size: number): number;
    convertToSamColorImage(width: number, height: number, pointerToRgbaImage: number, imageFormat: ObjectValues<typeof ImageFormat>, pointerToBgr0Image: number): number;
    detectDocumentWithImageParameters(width: number, height: number, pointerToImage: number, paramWidth: number, paramHeight: number, documentDetectionOptions: number): RawDetectedDocument;
    detectFacePartsWithImageParameters(width: number, height: number, pointerToImage: number, faceDetectionOptions: number, paramWidth: number, paramHeight: number): RawDetectedFace;
    detectPalmAttributes(width: number, height: number, pointerToImage: number, options: number, detectedPalmCorners: Array<number>): RawPalmAttributes;
    detectPalmWithImageParameters(width: number, height: number, pointerToImage: number, palmDetectionOptions: number, paramWidth: number, paramHeight: number): RawDetectedPalm;
    getInfoString(): Promise<string>;
    HEAP16: Int16Array;
    HEAP32: Int32Array;
    HEAP8: Int8Array;
    HEAPF32: Float32Array;
    HEAPF64: Float64Array;
    HEAPU16: Uint16Array;
    HEAPU32: Uint32Array;
    HEAPU8: Uint8Array;
    init(): void;
    selectDetailRegion(width: number, height: number, pointerToImage: number, detectedObjectBoundingBox: Array<number>): Promise<CropPositionAndSize>;
    terminate(): void;
} & WebAssembly.Module;
export type RawDetectedSamObject = {
    confidence: number;
    x0: number;
    x1: number;
    x2: number;
    x3: number;
    y0: number;
    y1: number;
    y2: number;
    y3: number;
};
export type CropPositionAndSize = {
    height: number;
    width: number;
    x: number;
    y: number;
};
export type EmscriptenEnum<T = number> = {
    [key: string]: unknown;
    value: T;
};
export type ImageProcessorResult<TDetectedObject, TValidationChecks> = {
    detection: TDetectedObject;
    isValid: boolean;
    validationResult: ValidationResult<keyof TValidationChecks>;
};
export type DetectionDetails<TDetectedObject, TInstructionCode> = {
    avgFps: number;
    detectionTime: number;
    fps: number;
    processedImage: ProcessedImage<TDetectedObject, TInstructionCode>;
    resolution: Resolution;
};
export type ProcessedImage<TDetection, TInstructionCode> = {
    detection: TDetection;
    instructionCode: TInstructionCode;
    invalidValidators: TInstructionCode[];
    isEscalated: boolean;
    isInCandidateSelection: boolean;
};
export type MimeType = 'image/jpeg' | 'image/png';
export type ImageCandidate<TImage extends Blob | HTMLCanvasElement, TDetection> = {
    detection: TDetection;
    takenPhoto: TakenPhoto<TImage>;
};
/**
 * One image from the candidate selection window with the detection that was found in it, encoded
 * as a Blob. This is the delivered form; `ImageCandidate` is the internal one, whose canvas is
 * still wrapped in a TakenPhoto.
 */
export type CandidateSelectionImage<TDetection> = {
    detection: TDetection;
    image: Blob;
};
export type CroppedImageWithPosition = {
    croppedImage: Blob;
    topLeftCorner: {
        x: number;
        y: number;
    };
};
export type RawImageParameters = ImageParameters & {
    hotspots: number;
};
export type OnComplete<TResultImageWithMetadata = unknown> = {
    content: Uint8Array;
    resultData: TResultImageWithMetadata;
};
export type DeviceMotionEventAccelerationZAxis = Omit<DeviceMotionEventAcceleration, 'x' | 'y'> | null;
export declare const AppTier: {
    readonly FREEMIUM: "FREEMIUM";
    readonly PREMIUM: "PREMIUM";
};
export type AppTierValues = ObjectValues<typeof AppTier>;
export type TakenPhoto<T> = {
    image: T;
    timestamp: number;
};
export type ValidationResult<T> = Map<T, boolean>;
export type AutoCaptureInstructionCodeMap<TInstructionCode> = {
    CANDIDATE_SELECTION: TInstructionCode;
};
export type InstructionEscalationConfig<I> = {
    instructions: Array<I>;
    threshold: number;
    timeout: number;
};
export type KeypressDetectionResult = {
    hasBeenDetected: boolean;
    keypressAmount?: number;
    timeToFirstKeypress?: number;
};
export type CameraEvaluationResult = {
    cameraData: Array<CameraData>;
};
export declare const ThresholdsPresetType: {
    readonly MOBILE: "MOBILE";
    readonly DESKTOP: "DESKTOP";
};
export type ThresholdsPresetTypeValues = ObjectValues<typeof ThresholdsPresetType>;
export type Thresholds<T extends Record<string, unknown>> = T;
export type OnCaptureMetadata<TDetectedObject> = {
    averageFps: number;
    cameraEvaluation: CameraEvaluationResult;
    cameraProperties: Pick<dot.v4.IWebMetadata, 'currentCameraProperties' | 'availableCameraProperties'>;
    candidateSelectionImages?: Array<ImageCandidate<HTMLCanvasElement, TDetectedObject>>;
    captureProcessTime: number;
    croppedImageWithPosition: CroppedImageWithPosition;
    detectionRecord: Array<DetectedObjectWithTimestamp<TDetectedObject>>;
    deviceName?: string;
    facingMode?: string;
    hashedDetectedImagesWithTimestamp: Array<dot.v4.IHashedDetectedImageWithTimestamp>;
    keypressDetection: KeypressDetectionResult;
    sessionToken?: string;
    timestamp: number;
};
export type OnDetectionCallbackParams<TDetectedObject, TInstructionCode> = {
    detectionDetails: DetectionDetails<TDetectedObject, TInstructionCode>;
    image: HTMLCanvasElement;
};
export type DetectedObjectWithTimestamp<TDetectedObject> = {
    detectedObject: TDetectedObject;
    timestamp: number;
};
export type OnCaptureCallbackParams<TDetectedObject> = {
    detectedObject: TDetectedObject;
    metadata: OnCaptureMetadata<TDetectedObject>;
    resultImage: HTMLCanvasElement;
    timestamp: number;
};
