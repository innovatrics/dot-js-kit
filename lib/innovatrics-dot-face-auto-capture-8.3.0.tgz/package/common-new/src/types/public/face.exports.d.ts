export * from '../../../../ui-common/src/error/auto-capture-error.js';
export * from '../../../../ui-common/src/types/common.js';
export * from '../../../../ui-common/src/types/face.js';
export type { DetectedFace, DetectedFaceCorners, DetectedFacePart, FaceImageParameters, } from '../../../../ui-common/src/types/modality/detection/face.js';
export type { CameraFacingMode, CameraFacingModeValues, CaptureMode, CaptureModeValues } from './common';
export * from './face';
