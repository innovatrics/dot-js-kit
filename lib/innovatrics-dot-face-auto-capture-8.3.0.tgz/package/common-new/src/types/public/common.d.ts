import type { ObjectValues } from '../../../../ui-common/src/types/common.js';
export declare const CameraFacingMode: {
    readonly FRONT: "user";
    readonly BACK: "environment";
};
export type CameraFacingModeValues = ObjectValues<typeof CameraFacingMode>;
export declare const CaptureMode: {
    readonly AUTO_CAPTURE: "AUTO_CAPTURE";
    readonly WAIT_FOR_REQUEST: "WAIT_FOR_REQUEST";
};
export type CaptureModeValues = ObjectValues<typeof CaptureMode>;
