import type { BaseConfiguration, CaptureConfiguration } from './configuration';
import type { EyeThresholds, MouthThresholds } from '../modality/face';
import type { CallbackImage, CustomElement, MaxInterval, MinInterval, MinOrMaxInterval, Resolution } from '../../../../ui-common/src/types/common.js';
import type { DetectedFace } from '../../../../ui-common/src/types/modality/detection/face.js';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-face-auto-capture': CustomElement<{
                configuration: FaceConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-face-auto-capture': CustomElement<{
                configuration: FaceConfiguration;
            }>;
        }
    }
}
export type { EyeThresholds, MouthThresholds };
export type HTMLFaceCaptureElement = HTMLElement & {
    configuration: FaceConfiguration;
};
export type FaceThresholds = {
    brightness?: MinOrMaxInterval;
    confidence?: MinInterval;
    devicePitchAngle?: MaxInterval;
    edgeDistanceToImageShorterSideRatio?: MinInterval;
    leftEye?: EyeThresholds;
    mouth?: MouthThresholds;
    rightEye?: EyeThresholds;
    sharpness?: MinInterval;
    size?: MinOrMaxInterval;
};
export type PublicFaceThresholds = Omit<FaceThresholds, 'leftEye' | 'rightEye' | 'mouth'>;
export type FaceComponentData = {
    detection: DetectedFace;
    imageResolution: Resolution;
};
export type FaceConfiguration<T = PublicFaceThresholds> = BaseConfiguration<CallbackImage<DetectedFace>> & CaptureConfiguration<T>;
export type FaceOnCompleteCallbackImage = CallbackImage<DetectedFace>;
export type FaceOnCompleteCallback = FaceConfiguration['onComplete'];
