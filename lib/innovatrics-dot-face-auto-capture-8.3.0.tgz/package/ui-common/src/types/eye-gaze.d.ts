import type { ObjectValues } from './common';
export declare const EyeGazeInstructionCodeValues: {
    readonly WATCH_THE_OBJECT: "watch_the_object";
    readonly CANDIDATE_SELECTION: "candidate_selection";
    readonly FACE_TOO_CLOSE: "face_too_close";
    readonly FACE_TOO_FAR: "face_too_far";
    readonly FACE_CENTERING: "face_centering";
    readonly FACE_NOT_PRESENT: "face_not_present";
    readonly SHARPNESS_TOO_LOW: "sharpness_too_low";
    readonly BRIGHTNESS_TOO_LOW: "brightness_too_low";
    readonly BRIGHTNESS_TOO_HIGH: "brightness_too_high";
    readonly DEVICE_PITCHED: "device_pitched";
    readonly LEFT_EYE_NOT_PRESENT: "left_eye_not_present";
    readonly RIGHT_EYE_NOT_PRESENT: "right_eye_not_present";
    readonly MOUTH_NOT_PRESENT: "mouth_not_present";
    readonly MOUTH_SCORE_TOO_HIGH: "mouth_score_too_high";
    readonly MOUTH_SCORE_TOO_LOW: "mouth_score_too_low";
};
export type EyeGazeInstructionCode = ObjectValues<typeof EyeGazeInstructionCodeValues>;
export declare const EyeGazePhaseValues: {
    readonly VALIDATION: "VALIDATION";
    readonly COLLECTION: "COLLECTION";
};
export type EyeGazePhase = ObjectValues<typeof EyeGazePhaseValues>;
export declare const EyeGazeStateValues: {
    readonly DONE: "done";
    readonly LOADING: "loading";
    readonly ERROR: "error";
    readonly WAITING: "waiting";
    readonly RUNNING: "running";
    readonly COMPLETE: "complete";
    readonly BLURRED: "blurred";
};
export type EyeGazeState = ObjectValues<typeof EyeGazeStateValues>;
export declare const Corner: {
    readonly TOP_LEFT: "TOP_LEFT";
    readonly TOP_RIGHT: "TOP_RIGHT";
    readonly BOTTOM_RIGHT: "BOTTOM_RIGHT";
    readonly BOTTOM_LEFT: "BOTTOM_LEFT";
};
export type CornerValues = ObjectValues<typeof Corner>;
