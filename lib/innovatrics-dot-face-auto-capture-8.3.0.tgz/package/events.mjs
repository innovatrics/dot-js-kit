const T = {};
T.CONTINUE_DETECTION = "continue-detection", T.SWITCH_CAMERA = "switch-camera", T.TOGGLE_MIRROR = "toggle-mirror";
const I = T, O = {};
O.FIRST_FRAME = "first-frame", O.FIRST_VALID_FRAME = "first-valid-frame";
const H = O, i = {};
i.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const u = i, a = (_, s) => {
  const E = {};
  E.detail = s, document.dispatchEvent(new CustomEvent(_, E));
}, h = (_, s) => {
  const E = {};
  E.instruction = s, a(_, E);
};
function d(_) {
  const s = {};
  s.instruction = _;
  const E = s;
  a(u.REQUEST_CAPTURE, E);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const C = n, N = { ...C };
N.DONE = "done";
const A = N, r = {};
r.EYE_NOT_PRESENT = "eye_not_present";
const c = r, o = {};
o.CANDIDATE_SELECTION = "candidate_selection", o.FACE_TOO_CLOSE = "face_too_close", o.FACE_TOO_FAR = "face_too_far", o.FACE_CENTERING = "face_centering", o.FACE_NOT_PRESENT = "face_not_present", o.SHARPNESS_TOO_LOW = "sharpness_too_low", o.BRIGHTNESS_TOO_LOW = "brightness_too_low", o.BRIGHTNESS_TOO_HIGH = "brightness_too_high", o.DEVICE_PITCHED = "device_pitched", o.LEFT_EYE_NOT_PRESENT = "left_" + c.EYE_NOT_PRESENT, o.RIGHT_EYE_NOT_PRESENT = "right_" + c.EYE_NOT_PRESENT, o.MOUTH_NOT_PRESENT = "mouth_not_present", o.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", o.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const e = o, t = {};
t.isPresent = e.FACE_NOT_PRESENT, t.isNotPitched = e.DEVICE_PITCHED, t.isNotSmall = e.FACE_TOO_FAR, t.isNotLarge = e.FACE_TOO_CLOSE, t.isNotOutOfBounds = e.FACE_CENTERING, t.isNotDim = e.BRIGHTNESS_TOO_LOW, t.isNotBright = e.BRIGHTNESS_TOO_HIGH, t.isSharp = e.SHARPNESS_TOO_LOW, t.isLeftEyePresent = e.LEFT_EYE_NOT_PRESENT, t.isRightEyePresent = e.RIGHT_EYE_NOT_PRESENT, t.isMouthPresent = e.MOUTH_NOT_PRESENT, t.isMouthScoreNotTooHigh = e.MOUTH_SCORE_TOO_HIGH, t.isMouthScoreNotTooLow = e.MOUTH_SCORE_TOO_LOW, t.isMouthStatusNotTooHigh = e.MOUTH_SCORE_TOO_HIGH, t.isMouthStatusNotTooLow = e.MOUTH_SCORE_TOO_LOW;
const p = t;
var R = ((_) => (_.CAMERA_PROPS_CHANGED = "face-auto-capture:camera-props-changed", _.CONTROL = "face-auto-capture:control", _.DETECTION_CHANGED = "face-auto-capture:detection-changed", _.FACE_DETECTION = "face-auto-capture:face-detection", _.INSTRUCTION_CHANGED = "face-auto-capture:instruction-changed", _.STATE_CHANGED = "face-auto-capture:state-changed", _.VIDEO_ELEMENT_SIZE = "face-auto-capture:video-element-size", _))(R || {});
export {
  C as AppStateValues,
  u as ComponentCustomEvent,
  I as ControlEventInstruction,
  c as EyeInstructionCodeValues,
  p as FaceCheckToInstructionCodeMap,
  R as FaceCustomEvent,
  e as FaceInstructionCodeValues,
  A as LivenessStateValues,
  H as RequestCaptureInstruction,
  d as dispatchCaptureEvent,
  h as dispatchControlEvent
};
