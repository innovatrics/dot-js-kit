const s = {};
s.CONTINUE_DETECTION = "continue-detection", s.SWITCH_CAMERA = "switch-camera", s.TOGGLE_MIRROR = "toggle-mirror";
const p = s, a = {};
a.FIRST_FRAME = "first-frame", a.FIRST_VALID_FRAME = "first-valid-frame";
const d = a, E = {};
E.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const _ = E, i = (c, n) => {
  const e = {};
  e.detail = n, document.dispatchEvent(new CustomEvent(c, e));
}, m = (c, n) => {
  const e = {};
  e.instruction = n, i(c, e);
};
function N(c) {
  const n = {};
  n.instruction = c;
  const e = n;
  i(_.REQUEST_CAPTURE, e);
}
const o = {};
o.LOADING = "loading", o.ERROR = "error", o.WAITING = "waiting", o.RUNNING = "running", o.COMPLETE = "complete";
const C = o, u = { ...C };
u.DONE = "done";
const R = u, r = {};
r.EYE_NOT_PRESENT = "eye_not_present";
const l = r, t = {};
t.DETECTION_CHANGED = "smile-auto-capture:detection-changed", t.CAMERA_PROPS_CHANGED = "smile-auto-capture:camera-props-changed", t.CONTROL = "smile-auto-capture:control", t.INSTRUCTION_CHANGED = "smile-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "smile-auto-capture:instruction-escalated", t.VIDEO_ELEMENT_SIZE = "smile-auto-capture:video-element-size", t.STATE_CHANGED = "smile-auto-capture:state-changed", t.PHASE_CHANGED = "smile-auto-capture:phase-changed";
const A = t;
export {
  C as AppStateValues,
  _ as ComponentCustomEvent,
  p as ControlEventInstruction,
  l as EyeInstructionCodeValues,
  R as LivenessStateValues,
  d as RequestCaptureInstruction,
  A as SmileCustomEvent,
  N as dispatchCaptureEvent,
  m as dispatchControlEvent
};
