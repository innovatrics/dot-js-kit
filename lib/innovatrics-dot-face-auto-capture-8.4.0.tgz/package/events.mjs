const c = {};
c.CONTINUE_DETECTION = "continue-detection", c.SWITCH_CAMERA = "switch-camera", c.TOGGLE_MIRROR = "toggle-mirror";
const I = c, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const H = T, i = {};
i.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const u = i, a = (_, s) => {
  const E = {};
  E.detail = s, document.dispatchEvent(new CustomEvent(_, E));
}, h = (_, s) => {
  const E = {};
  E.instruction = s, a(_, E);
};
function A(_) {
  const s = {};
  s.instruction = _;
  const E = s;
  a(u.REQUEST_CAPTURE, E);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const C = n, N = { ...C };
N.DONE = "done";
const d = N, r = {};
r.EYE_NOT_PRESENT = "eye_not_present";
const O = r, e = {};
e.CANDIDATE_SELECTION = "candidate_selection", e.FACE_TOO_CLOSE = "face_too_close", e.FACE_TOO_FAR = "face_too_far", e.FACE_CENTERING = "face_centering", e.FACE_NOT_PRESENT = "face_not_present", e.SHARPNESS_TOO_LOW = "sharpness_too_low", e.BRIGHTNESS_TOO_LOW = "brightness_too_low", e.BRIGHTNESS_TOO_HIGH = "brightness_too_high", e.DEVICE_PITCHED = "device_pitched", e.LEFT_EYE_NOT_PRESENT = "left_" + O.EYE_NOT_PRESENT, e.RIGHT_EYE_NOT_PRESENT = "right_" + O.EYE_NOT_PRESENT, e.MOUTH_NOT_PRESENT = "mouth_not_present", e.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", e.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const o = e, t = {};
t.isPresent = o.FACE_NOT_PRESENT, t.isNotPitched = o.DEVICE_PITCHED, t.isNotSmall = o.FACE_TOO_FAR, t.isNotLarge = o.FACE_TOO_CLOSE, t.isNotOutOfBounds = o.FACE_CENTERING, t.isNotDim = o.BRIGHTNESS_TOO_LOW, t.isNotBright = o.BRIGHTNESS_TOO_HIGH, t.isSharp = o.SHARPNESS_TOO_LOW, t.isLeftEyePresent = o.LEFT_EYE_NOT_PRESENT, t.isRightEyePresent = o.RIGHT_EYE_NOT_PRESENT, t.isMouthPresent = o.MOUTH_NOT_PRESENT, t.isMouthScoreNotTooHigh = o.MOUTH_SCORE_TOO_HIGH, t.isMouthScoreNotTooLow = o.MOUTH_SCORE_TOO_LOW, t.isMouthStatusNotTooHigh = o.MOUTH_SCORE_TOO_HIGH, t.isMouthStatusNotTooLow = o.MOUTH_SCORE_TOO_LOW;
const p = t;
var R = ((_) => (_.CAMERA_PROPS_CHANGED = "face-auto-capture:camera-props-changed", _.CONTROL = "face-auto-capture:control", _.DETECTION_CHANGED = "face-auto-capture:detection-changed", _.FACE_DETECTION = "face-auto-capture:face-detection", _.INSTRUCTION_CHANGED = "face-auto-capture:instruction-changed", _.STATE_CHANGED = "face-auto-capture:state-changed", _.VIDEO_ELEMENT_SIZE = "face-auto-capture:video-element-size", _))(R || {});
export {
  C as AppStateValues,
  u as ComponentCustomEvent,
  I as ControlEventInstruction,
  O as EyeInstructionCodeValues,
  p as FaceCheckToInstructionCodeMap,
  R as FaceCustomEvent,
  o as FaceInstructionCodeValues,
  d as LivenessStateValues,
  H as RequestCaptureInstruction,
  A as dispatchCaptureEvent,
  h as dispatchControlEvent
};
