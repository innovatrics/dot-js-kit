const _ = {};
_.CONTINUE_DETECTION = "continue-detection", _.SWITCH_CAMERA = "switch-camera", _.TOGGLE_MIRROR = "toggle-mirror";
const S = _, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const d = T, u = {};
u.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const a = u, r = (t, E) => {
  const n = {};
  n.detail = E, document.dispatchEvent(new CustomEvent(t, n));
}, I = (t, E) => {
  const n = {};
  n.instruction = E, r(t, n);
};
function m(t) {
  const E = {};
  E.instruction = t;
  const n = E;
  r(a.REQUEST_CAPTURE, n);
}
const s = {};
s.LOADING = "loading", s.ERROR = "error", s.WAITING = "waiting", s.RUNNING = "running", s.COMPLETE = "complete", s.BLURRED = "blurred";
const i = s, O = { ...i };
O.DONE = "done";
const p = O, N = {};
N.EYE_NOT_PRESENT = "eye_not_present";
const A = N, o = {};
o.CANDIDATE_SELECTION = "candidate_selection", o.DOCUMENT_CENTERING = "document_centering", o.DOCUMENT_NOT_PRESENT = "document_not_present", o.DOCUMENT_TOO_FAR = "document_too_far", o.SHARPNESS_TOO_LOW = "sharpness_too_low", o.BRIGHTNESS_TOO_LOW = "brightness_too_low", o.BRIGHTNESS_TOO_HIGH = "brightness_too_high", o.HOTSPOTS_PRESENT = "hotspots_present";
const c = o, e = {};
e.isPresent = c.DOCUMENT_NOT_PRESENT, e.isNotSmall = c.DOCUMENT_TOO_FAR, e.isNotOutOfBounds = c.DOCUMENT_CENTERING, e.isSharp = c.SHARPNESS_TOO_LOW, e.isNotDim = c.BRIGHTNESS_TOO_LOW, e.isNotBright = c.BRIGHTNESS_TOO_HIGH, e.noHotspots = c.HOTSPOTS_PRESENT;
const D = e;
var C = ((t) => (t.CAMERA_PROPS_CHANGED = "document-auto-capture:camera-props-changed", t.CONTROL = "document-auto-capture:control", t.DETECTION_CHANGED = "document-auto-capture:detection-changed", t.INSTRUCTION_CHANGED = "document-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "document-auto-capture:instruction-escalated", t.STATE_CHANGED = "document-auto-capture:state-changed", t.VIDEO_ELEMENT_SIZE = "document-auto-capture:video-element-size", t))(C || {});
export {
  i as AppStateValues,
  a as ComponentCustomEvent,
  S as ControlEventInstruction,
  D as DocumentCheckToInstructionCodeMap,
  C as DocumentCustomEvent,
  c as DocumentInstructionCodeValues,
  A as EyeInstructionCodeValues,
  p as LivenessStateValues,
  d as RequestCaptureInstruction,
  m as dispatchCaptureEvent,
  I as dispatchControlEvent
};
