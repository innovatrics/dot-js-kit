const c = {};
c.CONTINUE_DETECTION = "continue-detection", c.SWITCH_CAMERA = "switch-camera", c.TOGGLE_MIRROR = "toggle-mirror";
const R = c, u = {};
u.FIRST_FRAME = "first-frame", u.FIRST_VALID_FRAME = "first-valid-frame";
const T = u, s = {};
s.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const _ = s, E = (a, o) => {
  const e = {};
  e.detail = o, document.dispatchEvent(new CustomEvent(a, e));
}, p = (a, o) => {
  const e = {};
  e.instruction = o, E(a, e);
};
function N(a) {
  const o = {};
  o.instruction = a;
  const e = o;
  E(_.REQUEST_CAPTURE, e);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const C = n, r = { ...C };
r.DONE = "done";
const A = r, i = {};
i.EYE_NOT_PRESENT = "eye_not_present";
const m = i, t = {};
t.DETECTION_CHANGED = "multi-range-auto-capture:detection-changed", t.CAMERA_PROPS_CHANGED = "multi-range-auto-capture:camera-props-changed", t.CONTROL = "multi-range-auto-capture:control", t.PHASE_CHANGED = "multi-range-auto-capture:phase-changed", t.INSTRUCTION_CHANGED = "multi-range-auto-capture:instruction-changed", t.INSTRUCTION_ESCALATED = "multi-range-auto-capture:instruction-escalated", t.VIDEO_ELEMENT_SIZE = "multi-range-auto-capture:video-element-size", t.CHALLENGE_VALUE_CHANGED = "multi-range-auto-capture:challenge-value-changed", t.STATE_CHANGED = "multi-range-auto-capture:state-changed";
const d = t;
export {
  C as AppStateValues,
  _ as ComponentCustomEvent,
  R as ControlEventInstruction,
  m as EyeInstructionCodeValues,
  A as LivenessStateValues,
  d as MultiRangeCustomEvent,
  T as RequestCaptureInstruction,
  N as dispatchCaptureEvent,
  p as dispatchControlEvent
};
