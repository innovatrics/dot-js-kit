const c = {};
c.CONTINUE_DETECTION = "continue-detection", c.SWITCH_CAMERA = "switch-camera", c.TOGGLE_MIRROR = "toggle-mirror";
const I = c, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const A = T, a = {};
a.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const C = a, r = (e, s) => {
  const _ = {};
  _.detail = s, document.dispatchEvent(new CustomEvent(e, _));
}, h = (e, s) => {
  const _ = {};
  _.instruction = s, r(e, _);
};
function H(e) {
  const s = {};
  s.instruction = e;
  const _ = s;
  r(C.REQUEST_CAPTURE, _);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const R = n, i = { ...R };
i.DONE = "done";
const p = i, N = {};
N.EYE_NOT_PRESENT = "eye_not_present";
const O = N, t = {};
t.CANDIDATE_SELECTION = "candidate_selection", t.FACE_TOO_CLOSE = "face_too_close", t.FACE_TOO_FAR = "face_too_far", t.FACE_CENTERING = "face_centering", t.FACE_NOT_PRESENT = "face_not_present", t.SHARPNESS_TOO_LOW = "sharpness_too_low", t.BRIGHTNESS_TOO_LOW = "brightness_too_low", t.BRIGHTNESS_TOO_HIGH = "brightness_too_high", t.DEVICE_PITCHED = "device_pitched", t.LEFT_EYE_NOT_PRESENT = "left_" + O.EYE_NOT_PRESENT, t.RIGHT_EYE_NOT_PRESENT = "right_" + O.EYE_NOT_PRESENT, t.MOUTH_NOT_PRESENT = "mouth_not_present", t.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", t.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const E = t, o = {};
o.isPresent = E.FACE_NOT_PRESENT, o.isNotPitched = E.DEVICE_PITCHED, o.isNotSmall = E.FACE_TOO_FAR, o.isNotLarge = E.FACE_TOO_CLOSE, o.isNotOutOfBounds = E.FACE_CENTERING, o.isNotDim = E.BRIGHTNESS_TOO_LOW, o.isNotBright = E.BRIGHTNESS_TOO_HIGH, o.isSharp = E.SHARPNESS_TOO_LOW, o.isLeftEyePresent = E.LEFT_EYE_NOT_PRESENT, o.isRightEyePresent = E.RIGHT_EYE_NOT_PRESENT, o.isMouthPresent = E.MOUTH_NOT_PRESENT, o.isMouthScoreNotTooHigh = E.MOUTH_SCORE_TOO_HIGH, o.isMouthScoreNotTooLow = E.MOUTH_SCORE_TOO_LOW;
const d = o;
var u = ((e) => (e.CAMERA_PROPS_CHANGED = "face-auto-capture:camera-props-changed", e.CONTROL = "face-auto-capture:control", e.DETECTION_CHANGED = "face-auto-capture:detection-changed", e.FACE_DETECTION = "face-auto-capture:face-detection", e.INSTRUCTION_CHANGED = "face-auto-capture:instruction-changed", e.STATE_CHANGED = "face-auto-capture:state-changed", e.VIDEO_ELEMENT_SIZE = "face-auto-capture:video-element-size", e))(u || {});
export {
  R as AppStateValues,
  C as ComponentCustomEvent,
  I as ControlEventInstruction,
  O as EyeInstructionCodeValues,
  d as FaceCheckToInstructionCodeMap,
  u as FaceCustomEvent,
  E as FaceInstructionCodeValues,
  p as LivenessStateValues,
  A as RequestCaptureInstruction,
  H as dispatchCaptureEvent,
  h as dispatchControlEvent
};
