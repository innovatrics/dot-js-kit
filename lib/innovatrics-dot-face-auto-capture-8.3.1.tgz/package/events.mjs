const s = {};
s.CONTINUE_DETECTION = "continue-detection", s.SWITCH_CAMERA = "switch-camera", s.TOGGLE_MIRROR = "toggle-mirror";
const I = s, T = {};
T.FIRST_FRAME = "first-frame", T.FIRST_VALID_FRAME = "first-valid-frame";
const H = T, a = {};
a.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const u = a, i = (_, c) => {
  const E = {};
  E.detail = c, document.dispatchEvent(new CustomEvent(_, E));
}, h = (_, c) => {
  const E = {};
  E.instruction = c, i(_, E);
};
function d(_) {
  const c = {};
  c.instruction = _;
  const E = c;
  i(u.REQUEST_CAPTURE, E);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const C = n, N = { ...C };
N.DONE = "done";
const A = N, r = {};
r.EYE_NOT_PRESENT = "eye_not_present";
const O = r, e = {};
e.CANDIDATE_SELECTION = "candidate_selection", e.FACE_TOO_CLOSE = "face_too_close", e.FACE_TOO_FAR = "face_too_far", e.FACE_CENTERING = "face_centering", e.FACE_NOT_PRESENT = "face_not_present", e.SHARPNESS_TOO_LOW = "sharpness_too_low", e.BRIGHTNESS_TOO_LOW = "brightness_too_low", e.BRIGHTNESS_TOO_HIGH = "brightness_too_high", e.DEVICE_PITCHED = "device_pitched", e.LEFT_EYE_NOT_PRESENT = "left_" + O.EYE_NOT_PRESENT, e.RIGHT_EYE_NOT_PRESENT = "right_" + O.EYE_NOT_PRESENT, e.MOUTH_NOT_PRESENT = "mouth_not_present", e.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", e.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const o = e, t = {};
t.isPresent = o.FACE_NOT_PRESENT, t.isNotPitched = o.DEVICE_PITCHED, t.isNotSmall = o.FACE_TOO_FAR, t.isNotLarge = o.FACE_TOO_CLOSE, t.isNotOutOfBounds = o.FACE_CENTERING, t.isNotDim = o.BRIGHTNESS_TOO_LOW, t.isNotBright = o.BRIGHTNESS_TOO_HIGH, t.isSharp = o.SHARPNESS_TOO_LOW, t.isLeftEyePresent = o.LEFT_EYE_NOT_PRESENT, t.isRightEyePresent = o.RIGHT_EYE_NOT_PRESENT, t.isMouthPresent = o.MOUTH_NOT_PRESENT, t.isMouthScoreNotTooHigh = o.MOUTH_SCORE_TOO_HIGH, t.isMouthScoreNotTooLow = o.MOUTH_SCORE_TOO_LOW, t.isMouthStatusNotTooHigh = o.MOUTH_SCORE_TOO_HIGH, t.isMouthStatusNotTooLow = o.MOUTH_SCORE_TOO_LOW;
const f = t;
var R = ((_) => (_.CAMERA_PROPS_CHANGED = "face-auto-capture:camera-props-changed", _.CONTROL = "face-auto-capture:control", _.DETECTION_CHANGED = "face-auto-capture:detection-changed", _.FACE_DETECTION = "face-auto-capture:face-detection", _.INSTRUCTION_CHANGED = "face-auto-capture:instruction-changed", _.STATE_CHANGED = "face-auto-capture:state-changed", _.VIDEO_ELEMENT_SIZE = "face-auto-capture:video-element-size", _))(R || {});
export {
  C as AppStateValues,
  u as ComponentCustomEvent,
  I as ControlEventInstruction,
  O as EyeInstructionCodeValues,
  f as FaceCheckToInstructionCodeMap,
  R as FaceCustomEvent,
  o as FaceInstructionCodeValues,
  A as LivenessStateValues,
  H as RequestCaptureInstruction,
  d as dispatchCaptureEvent,
  h as dispatchControlEvent
};
