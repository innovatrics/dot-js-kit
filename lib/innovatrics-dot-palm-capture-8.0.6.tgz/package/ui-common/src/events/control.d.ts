import type { CommonCustomEvent, ControlEventInstructionValues, RequestCaptureInstructionValues } from '../types/events/common';
/**
 * It dispatches a custom event with the given event name and event detail
 * @param {CommonCustomEvent<string>['CONTROL']} eventName - The name of the event to
 * dispatch.
 * @param {ControlEventInstruction} instruction - ControlEventInstruction
 */
export declare const dispatchControlEvent: (eventName: CommonCustomEvent<string>["CONTROL"], instruction: ControlEventInstructionValues) => void;
export declare function dispatchCaptureEvent(instruction: RequestCaptureInstructionValues): void;
