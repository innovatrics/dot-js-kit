import type { InstructionChangeEvent } from './common';
import type { FaceInstructionCode } from '../face';
import type { DetectedFace } from '../modality/detection/face';
export declare enum FaceCustomEvent {
    CAMERA_PROPS_CHANGED = "face-auto-capture:camera-props-changed",
    CONTROL = "face-auto-capture:control",
    DETECTION_CHANGED = "face-auto-capture:detection-changed",
    /**
     * @deprecated Use DETECTION_CHANGED instead (will be removed in 9.0.0 major version)
     */
    FACE_DETECTION = "face-auto-capture:face-detection",
    INSTRUCTION_CHANGED = "face-auto-capture:instruction-changed",
    STATE_CHANGED = "face-auto-capture:state-changed",
    VIDEO_ELEMENT_SIZE = "face-auto-capture:video-element-size"
}
/**
 * @deprecated Use OnDetectionCallbackParams instead (will be removed in 9.0.0 major version)
 */
export type DetectedFaceChangeEvent = {
    detail?: {
        detectedObject: DetectedFace;
    };
} & Event;
export type FaceInstructionChangeEvent = InstructionChangeEvent<FaceInstructionCode>;
export type DispatchFaceDetectionEvent = {
    detection: DetectedFace;
    eventName: FaceCustomEvent.FACE_DETECTION;
};
