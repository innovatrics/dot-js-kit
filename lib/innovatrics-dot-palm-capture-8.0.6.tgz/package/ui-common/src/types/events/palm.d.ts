import type { InstructionChangeEvent } from './common';
import type { DetectedPalm } from '../modality/detection/palm';
import type { PalmInstructionCode } from '../palm';
export declare enum PalmCustomEvent {
    CAMERA_PROPS_CHANGED = "palm-capture:camera-props-changed",
    CONTROL = "palm-capture:control",
    DETECTION_CHANGED = "palm-capture:detection-changed",
    INSTRUCTION_CHANGED = "palm-capture:instruction-changed",
    STATE_CHANGED = "palm-capture:state-changed",
    VIDEO_ELEMENT_SIZE = "palm-capture:video-element-size"
}
export type DetectedPalmChangeEvent = {
    detail?: {
        detectedObject: DetectedPalm;
    };
} & Event;
export type PalmInstructionChangeEvent = InstructionChangeEvent<PalmInstructionCode>;
