import type { ObjectValues } from '../common';
import type { InstructionChangeEvent } from './common';
import type { MultiRangeInstructionCode } from '../multi-range';
export declare const MultiRangeCustomEvent: {
    readonly DETECTION_CHANGED: "multi-range-auto-capture:detection-changed";
    readonly CAMERA_PROPS_CHANGED: "multi-range-auto-capture:camera-props-changed";
    readonly CONTROL: "multi-range-auto-capture:control";
    readonly PHASE_CHANGED: "multi-range-auto-capture:phase-changed";
    readonly INSTRUCTION_CHANGED: "multi-range-auto-capture:instruction-changed";
    readonly INSTRUCTION_ESCALATED: "multi-range-auto-capture:instruction-escalated";
    readonly VIDEO_ELEMENT_SIZE: "multi-range-auto-capture:video-element-size";
    readonly CHALLENGE_VALUE_CHANGED: "multi-range-auto-capture:challenge-value-changed";
    readonly STATE_CHANGED: "multi-range-auto-capture:state-changed";
};
export type MultiRangeCustomEventValues = ObjectValues<typeof MultiRangeCustomEvent>;
export type MultiRangeInstructionChangeEvent = InstructionChangeEvent<MultiRangeInstructionCode>;
