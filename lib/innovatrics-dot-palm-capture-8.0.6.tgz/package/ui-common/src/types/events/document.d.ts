import type { InstructionChangeEvent, InstructionEscalatedEvent } from './common';
import type { DocumentInstructionCode } from '../document';
import type { DetectedDocument } from '../modality/detection/document';
export declare enum DocumentCustomEvent {
    CAMERA_PROPS_CHANGED = "document-auto-capture:camera-props-changed",
    CONTROL = "document-auto-capture:control",
    DETECTION_CHANGED = "document-auto-capture:detection-changed",
    INSTRUCTION_CHANGED = "document-auto-capture:instruction-changed",
    INSTRUCTION_ESCALATED = "document-auto-capture:instruction-escalated",
    STATE_CHANGED = "document-auto-capture:state-changed",
    VIDEO_ELEMENT_SIZE = "document-auto-capture:video-element-size"
}
export type DetectedDocumentChangeEvent = {
    detail?: {
        detectedObject: DetectedDocument;
    };
} & Event;
export type DocumentInstructionChangeEvent = InstructionChangeEvent<DocumentInstructionCode>;
export type DocumentInstructionEscalatedEvent = InstructionEscalatedEvent<DocumentInstructionCode>;
