import type { DocumentCustomEvent } from './document';
import type { FaceCustomEvent } from './face';
import type { PalmCustomEvent } from './palm';
import type { DocumentInstructionCode } from '../document';
import type { FaceInstructionCode } from '../face';
import type { PalmInstructionCode } from '../palm';
/**
 * @deprecated InstructionChangeEventCodeMap should be not used in new architecture (will be removed in 9.0.0 major version)
 * Each component should have its own event dispatcher class with proper type definitions
 */
export type InstructionChangeEventCodeMap = {
    [DocumentCustomEvent.INSTRUCTION_CHANGED]: DocumentInstructionCode;
    [FaceCustomEvent.INSTRUCTION_CHANGED]: FaceInstructionCode;
    [PalmCustomEvent.INSTRUCTION_CHANGED]: PalmInstructionCode;
};
/**
 * @deprecated CaptureCustomEvent should be not used in new architecture (will be removed in 9.0.0 major version)
 * use-camera-control-events and use-capture will be removed by migration to new architecture
 */
export type CaptureCustomEvent = typeof PalmCustomEvent | typeof DocumentCustomEvent | typeof FaceCustomEvent;
