import type { AutoCaptureError } from '../../error/auto-capture-error';
import type { AppState, ObjectValues, Resolution } from '../common';
export declare const ControlEventInstruction: {
    readonly CONTINUE_DETECTION: "continue-detection";
    readonly SWITCH_CAMERA: "switch-camera";
    readonly TOGGLE_MIRROR: "toggle-mirror";
};
export type ControlEventInstructionValues = ObjectValues<typeof ControlEventInstruction>;
export declare const RequestCaptureInstruction: {
    readonly FIRST_FRAME: "first-frame";
    readonly FIRST_VALID_FRAME: "first-valid-frame";
};
export type RequestCaptureInstructionValues = ObjectValues<typeof RequestCaptureInstruction>;
export declare const ComponentCustomEvent: {
    readonly REQUEST_CAPTURE: "dot-custom-event:request-capture";
};
export type ComponentCustomEventValues = ObjectValues<typeof ComponentCustomEvent>;
export type ControlEvent<T> = {
    detail?: {
        instruction: T;
    };
} & Event;
export type CameraPropsChangeEvent = {
    detail?: {
        cameraResolution: Resolution;
        isMirroring: boolean;
    };
} & Event;
export type CameraStateChangeEvent = {
    detail?: {
        appState: AppState;
        error?: AutoCaptureError;
    };
} & Event;
export type InstructionChangeEvent<T> = {
    detail?: {
        instructionCode: T;
        isEscalated: boolean;
    };
} & Event;
export type PhaseChangedEvent<T> = {
    detail?: {
        phaseName: T;
    };
} & Event;
export type InstructionEscalatedEvent<T> = {
    detail?: {
        instructionCode: T;
    };
} & Event;
export type VideoElementSizeChangeEvent = {
    detail?: {
        size: DOMRect;
    };
} & Event;
export type DetectionEvent<TDetectedObject, TInstructionCode extends string = string> = {
    detail?: {
        data: {
            detection: TDetectedObject;
            fps: number;
            imageResolution: Resolution;
            invalidValidators: Array<TInstructionCode>;
            isInCandidateSelection: boolean;
        };
        image: HTMLCanvasElement;
    };
} & Event;
type DetectionDetails<TDetectedObject, TInstructionCode> = {
    avgFps: number;
    detectionTime: number;
    fps: number;
    processedImage: ProcessedImage<TDetectedObject, TInstructionCode>;
    resolution: Resolution;
};
type ProcessedImage<TDetection, TInstructionCode> = {
    detection: TDetection;
    instructionCode: TInstructionCode;
    invalidValidators: TInstructionCode[];
    isEscalated: boolean;
    isInCandidateSelection: boolean;
};
export type DetectionChangedEvent<TDetectedObject, TInstructionCode> = {
    detail?: {
        detectionDetails: DetectionDetails<TDetectedObject, TInstructionCode>;
        image: HTMLCanvasElement;
    };
} & Event;
export type CommonCustomEventKeys = {
    CAMERA_PROPS_CHANGED: string;
    CONTROL: string;
    DETECTION_CHANGED: string;
    INSTRUCTION_CHANGED: string;
    INSTRUCTION_ESCALATED: string;
    PHASE_CHANGED: string;
    STATE_CHANGED: string;
    VIDEO_ELEMENT_SIZE: string;
};
type DashCase<T extends string> = T extends `${infer A}_${infer B}` ? `${Lowercase<A>}-${DashCase<B>}` : Lowercase<T>;
export type CommonCustomEvent<TPrefix extends string, TKeys extends CommonCustomEventKeys = CommonCustomEventKeys> = {
    [K in keyof TKeys]: `${TPrefix}:${DashCase<K & string>}`;
};
export {};
