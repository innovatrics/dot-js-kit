import type { InstructionEscalatedEvent } from './common';
import type { SmileInstructionCode } from '../smile';
export declare const SmileCustomEvent: {
    readonly DETECTION_CHANGED: "smile-auto-capture:detection-changed";
    readonly CAMERA_PROPS_CHANGED: "smile-auto-capture:camera-props-changed";
    readonly CONTROL: "smile-auto-capture:control";
    readonly INSTRUCTION_CHANGED: "smile-auto-capture:instruction-changed";
    readonly INSTRUCTION_ESCALATED: "smile-auto-capture:instruction-escalated";
    readonly VIDEO_ELEMENT_SIZE: "smile-auto-capture:video-element-size";
    readonly STATE_CHANGED: "smile-auto-capture:state-changed";
    readonly PHASE_CHANGED: "smile-auto-capture:phase-changed";
};
export type SmileInstructionEscalatedEvent = InstructionEscalatedEvent<SmileInstructionCode>;
