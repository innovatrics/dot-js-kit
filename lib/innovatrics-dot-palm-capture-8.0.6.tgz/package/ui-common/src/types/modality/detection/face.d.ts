import type { ImageParameters, Point } from '../../common';
export type DetectedFace = FaceImageParameters & DetectedFaceCorners & {
    confidence: number;
    faceSize: number;
    leftEye: DetectedFacePart;
    mouth: DetectedFacePart;
    rightEye: DetectedFacePart;
};
export type DetectedFacePart = {
    center: Point;
    confidence: number;
    size: number;
    status: number;
};
export type DetectedFaceCorners = {
    bottomRight: Point;
    faceCenter: Point;
    topLeft: Point;
};
export type FaceImageParameters = ImageParameters;
