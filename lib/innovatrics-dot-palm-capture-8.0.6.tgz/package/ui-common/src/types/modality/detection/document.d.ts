import type { DetectedCorners, ImageParameters } from '../../common';
export type DetectedDocumentCorners = DetectedCorners;
export type DocumentImageParameters = ImageParameters & {
    hotspots: number;
};
export type DetectedDocument = DocumentImageParameters & DetectedDocumentCorners & {
    confidence: number;
    smallestEdge: number;
};
