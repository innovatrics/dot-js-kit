import type { DetectedCorners, ImageParameters, ObjectValues } from '../../common';
export type DetectedPalmCorners = DetectedCorners;
export type PalmImageParameters = ImageParameters;
export type DetectedPalm = PalmQualityAttributes & PalmImageParameters & DetectedPalmCorners & {
    confidence: number;
    smallestEdge: number;
};
export type PalmQualityAttributes = {
    handOrientation: ObjectValues<typeof PalmHandOrientation>;
    handPosition: ObjectValues<typeof PalmHandPosition>;
    templateExtractionQuality: number;
};
export declare const PalmHandPosition: {
    readonly LEFT: "Left";
    readonly RIGHT: "Right";
};
export declare const PalmHandOrientation: {
    readonly PALMAR: "Palmar";
    readonly DORSAL: "Dorsal";
};
