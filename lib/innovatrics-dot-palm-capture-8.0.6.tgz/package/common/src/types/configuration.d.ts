import type { CallbackImage, ObjectValues } from '../../../ui-common/src/types/common';
export declare const CameraFacingMode: {
    readonly FRONT: "user";
    readonly BACK: "environment";
};
export type CameraFacingModeValues = ObjectValues<typeof CameraFacingMode>;
export declare const CaptureMode: {
    readonly AUTO_CAPTURE: "AUTO_CAPTURE";
    readonly WAIT_FOR_REQUEST: "WAIT_FOR_REQUEST";
};
export type CaptureModeValues = ObjectValues<typeof CaptureMode>;
export type CameraConfiguration = {
    facingMode?: CameraFacingModeValues;
    isVideoCaptureEnabled?: boolean;
};
export type CommonConfiguration = {
    assetsDirectoryPath?: string;
    captureMode?: CaptureModeValues;
    sessionToken?: string;
    styleTarget?: HTMLElement;
    transactionCountingToken?: string;
};
export type CallbackConfiguration<TDetectedObject> = {
    onComplete: (imageData: CallbackImage<TDetectedObject>, content: Uint8Array) => void;
    onError: (e: Error) => void;
};
export type AutoCaptureConfiguration = {
    candidateSelectionDurationMillis?: number;
};
export type BaseConfiguration<TDetectedObject, TQualityAttributeThresholds> = CommonConfiguration & CallbackConfiguration<TDetectedObject> & {
    autoCapture?: AutoCaptureConfiguration;
    camera?: CameraConfiguration;
    qualityAttributeThresholds?: TQualityAttributeThresholds;
};
