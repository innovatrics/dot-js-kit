import type { BaseConfiguration } from './configuration';
import type { CallbackImage, CustomElement, MinInterval, MinOrMaxInterval, Resolution } from '../../../ui-common/src/types';
import type { DetectedPalm } from '../../../ui-common/src/types/modality/detection/palm';
export * from '../../../ui-common/src/types/common';
export * from '../../../ui-common/src/types/palm';
export * from '../../../ui-common/src/error';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-palm-capture': CustomElement<{
                configuration: PalmConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-palm-capture': CustomElement<{
                configuration: PalmConfiguration;
            }>;
        }
    }
}
export type HTMLPalmCaptureElement = HTMLElement & {
    configuration: PalmConfiguration;
};
export type PalmThresholds = {
    brightness?: MinOrMaxInterval;
    confidence?: MinInterval;
    edgeDistanceToImageShorterSideRatio?: MinInterval;
    sharpness?: MinInterval;
    size?: MinOrMaxInterval;
    templateExtractionQuality?: MinInterval;
};
export type PalmComponentData = {
    detection: DetectedPalm;
    imageResolution: Resolution;
};
export type PalmConfiguration = BaseConfiguration<DetectedPalm, PalmThresholds>;
export type PalmOnCompleteCallbackImage = CallbackImage<DetectedPalm>;
export type PalmOnCompleteCallback = PalmConfiguration['onComplete'];
