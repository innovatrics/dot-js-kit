const T = {};
T.CONTINUE_DETECTION = "continue-detection", T.SWITCH_CAMERA = "switch-camera", T.TOGGLE_MIRROR = "toggle-mirror";
const H = T, O = {};
O.FIRST_FRAME = "first-frame", O.FIRST_VALID_FRAME = "first-valid-frame";
const P = O, a = {};
a.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const R = a, i = (t, s) => {
  const o = {};
  o.detail = s, document.dispatchEvent(new CustomEvent(t, o));
}, L = (t, s) => {
  const o = {};
  o.instruction = s, i(t, o);
};
function d(t) {
  const s = {};
  s.instruction = t;
  const o = s;
  i(R.REQUEST_CAPTURE, o);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const u = n, r = { ...u };
r.DONE = "done";
const C = r, N = {};
N.EYE_NOT_PRESENT = "eye_not_present";
const c = N, e = {};
e.CANDIDATE_SELECTION = "candidate_selection", e.FACE_TOO_CLOSE = "face_too_close", e.FACE_TOO_FAR = "face_too_far", e.FACE_CENTERING = "face_centering", e.FACE_NOT_PRESENT = "face_not_present", e.SHARPNESS_TOO_LOW = "sharpness_too_low", e.BRIGHTNESS_TOO_LOW = "brightness_too_low", e.BRIGHTNESS_TOO_HIGH = "brightness_too_high", e.DEVICE_PITCHED = "device_pitched", e.LEFT_EYE_NOT_PRESENT = "left_" + c.EYE_NOT_PRESENT, e.RIGHT_EYE_NOT_PRESENT = "right_" + c.EYE_NOT_PRESENT, e.MOUTH_NOT_PRESENT = "mouth_not_present", e.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", e.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const _ = e, E = {};
E.isPresent = _.FACE_NOT_PRESENT, E.isNotPitched = _.DEVICE_PITCHED, E.isNotSmall = _.FACE_TOO_FAR, E.isNotLarge = _.FACE_TOO_CLOSE, E.isNotOutOfBounds = _.FACE_CENTERING, E.isNotDim = _.BRIGHTNESS_TOO_LOW, E.isNotBright = _.BRIGHTNESS_TOO_HIGH, E.isSharp = _.SHARPNESS_TOO_LOW, E.isLeftEyePresent = _.LEFT_EYE_NOT_PRESENT, E.isRightEyePresent = _.RIGHT_EYE_NOT_PRESENT, E.isMouthPresent = _.MOUTH_NOT_PRESENT, E.isMouthScoreNotTooHigh = _.MOUTH_SCORE_TOO_HIGH, E.isMouthScoreNotTooLow = _.MOUTH_SCORE_TOO_LOW;
const S = { ..._ };
S.FIT_YOUR_EYE = "fit_your_eye";
const g = S;
var I = ((t) => (t.CLOSEUP = "CLOSEUP", t.DISTANT = "DISTANT", t.MIDDLE = "MIDDLE", t))(I || {});
const l = C;
var A = ((t) => (t.ANIMATION_END = "magnifeye-auto-capture:animation-end", t.CONTROL = "magnifeye-auto-capture:control", t.STATUS_CHANGED = "magnifeye-auto-capture:status-changed", t))(A || {});
export {
  u as AppStateValues,
  R as ComponentCustomEvent,
  H as ControlEventInstruction,
  c as EyeInstructionCodeValues,
  C as LivenessStateValues,
  A as MagnifEyeCustomEvent,
  g as MagnifEyeInstructionCodeValues,
  I as MagnifEyePhase,
  l as MagnifEyeStateValues,
  P as RequestCaptureInstruction,
  d as dispatchCaptureEvent,
  L as dispatchControlEvent
};
