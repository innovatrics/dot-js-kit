import type { BaseConfiguration } from './configuration';
import type { CallbackImage, CustomElement, MaxInterval, MinInterval, MinOrMaxInterval, Resolution } from '../../../ui-common/src/types';
import type { DetectedFace } from '../../../ui-common/src/types/modality/detection/face';
export * from '../../../ui-common/src/types/common';
export * from '../../../ui-common/src/types/face';
export * from '../../../ui-common/src/error';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-face-auto-capture': CustomElement<{
                configuration: FaceConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-face-auto-capture': CustomElement<{
                configuration: FaceConfiguration;
            }>;
        }
    }
}
export type HTMLFaceCaptureElement = HTMLElement & {
    configuration: FaceConfiguration;
};
export type FaceComponentData = {
    detection: DetectedFace;
    imageResolution: Resolution;
};
export type EyeThresholds = {
    confidence: MinInterval;
};
export type MouthThresholds = {
    confidence: MinInterval;
    status: {
        max: number;
        min?: number;
    } | {
        max?: number;
        min: number;
    };
};
export type FaceThresholds = {
    brightness?: MinOrMaxInterval;
    confidence?: MinInterval;
    devicePitchAngle?: MaxInterval;
    edgeDistanceToImageShorterSideRatio?: MinInterval;
    leftEye?: EyeThresholds;
    mouth?: MouthThresholds;
    rightEye?: EyeThresholds;
    sharpness?: MinInterval;
    size?: MinOrMaxInterval;
};
export type PublicFaceThresholds = Omit<FaceThresholds, 'leftEye' | 'rightEye' | 'mouth'>;
export type FaceConfiguration<T = PublicFaceThresholds> = BaseConfiguration<DetectedFace, T>;
export type FaceOnCompleteCallbackImage = CallbackImage<DetectedFace>;
export type FaceOnCompleteCallback = FaceConfiguration['onComplete'];
