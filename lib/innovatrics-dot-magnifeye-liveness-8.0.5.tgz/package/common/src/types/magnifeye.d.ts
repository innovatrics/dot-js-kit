import type { FaceComponentData, FaceConfiguration } from './face';
import type { CallbackImage, CustomElement } from '../../../ui-common/src/types';
import type { DetectedFace } from '../../../ui-common/src/types/modality/detection/face';
declare global {
    interface Window {
        DOT_DEBUG_MODE?: boolean;
    }
    namespace preact.JSX {
        interface IntrinsicElements {
            'x-dot-magnifeye-liveness': CustomElement<{
                configuration: MagnifEyeLivenessConfiguration;
            }>;
        }
    }
    namespace React.JSX {
        interface IntrinsicElements {
            'x-dot-magnifeye-liveness': CustomElement<{
                configuration: MagnifEyeLivenessConfiguration;
            }>;
        }
    }
}
export type MagnifEyeLivenessConfiguration = Pick<FaceConfiguration, 'assetsDirectoryPath' | 'onError' | 'sessionToken' | 'styleTarget' | 'transactionCountingToken' | 'onComplete' | 'camera'>;
export type HTMLMagnifEyeLivenessElement = HTMLElement & {
    configuration: MagnifEyeLivenessConfiguration;
};
export type MiddlePhotoCandidate = {
    data: FaceComponentData;
    image: HTMLCanvasElement;
};
export type MagnifEyeLivenessOnCompleteCallbackImage = CallbackImage<DetectedFace>;
export type MagnifEyeLivenessOnCompleteCallback = MagnifEyeLivenessConfiguration['onComplete'];
