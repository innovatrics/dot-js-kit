const T = {};
T.CONTINUE_DETECTION = "continue-detection", T.SWITCH_CAMERA = "switch-camera", T.TOGGLE_MIRROR = "toggle-mirror";
const H = T, c = {};
c.FIRST_FRAME = "first-frame", c.FIRST_VALID_FRAME = "first-valid-frame";
const P = c, i = {};
i.REQUEST_CAPTURE = "dot-custom-event:request-capture";
const R = i, r = (t, s) => {
  const o = {};
  o.detail = s, document.dispatchEvent(new CustomEvent(t, o));
}, L = (t, s) => {
  const o = {};
  o.instruction = s, r(t, o);
};
function g(t) {
  const s = {};
  s.instruction = t;
  const o = s;
  r(R.REQUEST_CAPTURE, o);
}
const n = {};
n.LOADING = "loading", n.ERROR = "error", n.WAITING = "waiting", n.RUNNING = "running", n.COMPLETE = "complete", n.BLURRED = "blurred";
const u = n, N = { ...u };
N.DONE = "done";
const C = N, a = {};
a.EYE_NOT_PRESENT = "eye_not_present";
const O = a, _ = {};
_.CANDIDATE_SELECTION = "candidate_selection", _.FACE_TOO_CLOSE = "face_too_close", _.FACE_TOO_FAR = "face_too_far", _.FACE_CENTERING = "face_centering", _.FACE_NOT_PRESENT = "face_not_present", _.SHARPNESS_TOO_LOW = "sharpness_too_low", _.BRIGHTNESS_TOO_LOW = "brightness_too_low", _.BRIGHTNESS_TOO_HIGH = "brightness_too_high", _.DEVICE_PITCHED = "device_pitched", _.LEFT_EYE_NOT_PRESENT = "left_" + O.EYE_NOT_PRESENT, _.RIGHT_EYE_NOT_PRESENT = "right_" + O.EYE_NOT_PRESENT, _.MOUTH_NOT_PRESENT = "mouth_not_present", _.MOUTH_SCORE_TOO_HIGH = "mouth_score_too_high", _.MOUTH_SCORE_TOO_LOW = "mouth_score_too_low";
const e = _, E = {};
E.isPresent = e.FACE_NOT_PRESENT, E.isNotPitched = e.DEVICE_PITCHED, E.isNotSmall = e.FACE_TOO_FAR, E.isNotLarge = e.FACE_TOO_CLOSE, E.isNotOutOfBounds = e.FACE_CENTERING, E.isNotDim = e.BRIGHTNESS_TOO_LOW, E.isNotBright = e.BRIGHTNESS_TOO_HIGH, E.isSharp = e.SHARPNESS_TOO_LOW, E.isLeftEyePresent = e.LEFT_EYE_NOT_PRESENT, E.isRightEyePresent = e.RIGHT_EYE_NOT_PRESENT, E.isMouthPresent = e.MOUTH_NOT_PRESENT, E.isMouthScoreNotTooHigh = e.MOUTH_SCORE_TOO_HIGH, E.isMouthScoreNotTooLow = e.MOUTH_SCORE_TOO_LOW;
const S = { ...e };
S.FIT_YOUR_EYE = "fit_your_eye";
const l = S;
var I = ((t) => (t.CLOSEUP = "CLOSEUP", t.DISTANT = "DISTANT", t.MIDDLE = "MIDDLE", t))(I || {});
const f = C;
var A = ((t) => (t.ANIMATION_END = "magnifeye-auto-capture:animation-end", t.CONTROL = "magnifeye-auto-capture:control", t.STATUS_CHANGED = "magnifeye-auto-capture:status-changed", t))(A || {});
export {
  u as AppStateValues,
  R as ComponentCustomEvent,
  H as ControlEventInstruction,
  O as EyeInstructionCodeValues,
  C as LivenessStateValues,
  A as MagnifEyeCustomEvent,
  l as MagnifEyeInstructionCodeValues,
  I as MagnifEyePhase,
  f as MagnifEyeStateValues,
  P as RequestCaptureInstruction,
  g as dispatchCaptureEvent,
  L as dispatchControlEvent
};
